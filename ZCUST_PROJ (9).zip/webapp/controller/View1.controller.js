sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/model/Filter',
	'sap/ui/model/Sorter',
	'sap/ui/model/json/JSONModel',
	'sap/m/Menu',
	'sap/m/MenuItem',
	"sap/ui/model/FilterOperator"
], function (Controller, Filter, Sorter, JSONModel, Menu, MenuItem, FilterOperator) {
	"use strict";

	return Controller.extend("test.ZCUST_PROJ.controller.View1", {
		onInit: function () {
			this._mViewSettingsDialogs = {};
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);//initialise Router on view

			var oFilter = this.getView().byId("Filterbar");//FilterBar instance
			
			//Change text of Filter Bar Go button to Execute Button
			oFilter.addEventDelegate({
				"onAfterRendering": function (oEvent) {

					var oButton = oEvent.srcControl._oSearchButton;
					oButton.setText("Execute");
				}
			});
			
			
		//	this.onExecute();//Load Summary Table Data
		//	this.onProductF4();//Load Product Key F4 Data

			var cutoverData = [{
				SeqNo: "1",
				CustId: "178908",
				Customer: "Walmart",
				Product: "Pixel 4a"
			}, {
				SeqNo: "2",
				CustId: "178909",
				Customer: "Amazon US",
				Product: "PixelBook"
			}];
			var SummaryTableModel = new sap.ui.model.json.JSONModel(cutoverData);
			this.getView().setModel(SummaryTableModel, "SummaryTableModel");

		},
		
		//Product Key Dialog instance
		onProductKeyF4Open: function (oEvent) {
			var model = this.getView().getModel("ProductKeyModel");

			if (!this.ProductDialogF4) {
				this.ProductDialogF4 = sap.ui.xmlfragment("test.ZCUST_PROJ.view.Fragments.ProductDialog", this);
				this.getView().addDependent(this.ProductDialogF4);
			}
			this.ProductDialogF4.open();
			this.ProductDialogF4.setModel(model);
		},

		onSuggestionItemSelected: function (oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("ProductKeyId").setValue(sDescription);
		},

		onValueHelpDialogCloseProduct: function (oEvent) {
			var sDescription,
				oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}
			sDescription = oSelectedItem.getTitle();
			this.getView().byId("ProductKeyId").setValue(sDescription);

		},

		onValueHelpDialogSearchProduct: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Description", FilterOperator.Contains, sValue);
			oEvent.getSource().getBinding("items").filter([oFilter]);
		},

		onProductF4: function (oEvent) {
			var oServiceModel = this.getOwnerComponent().getModel();
			var view = this.getView();
			var relPath = "/ProductKeySet";
			//Busy Dialog
			oServiceModel.attachRequestSent(function () {
				if (!view._oBusyDialog) {
					view._oBusyDialog = new sap.m.BusyDialog({
						title: "Please wait. . . "
					});
					view.addDependent(view._oBusyDialog);
				}
				view._oBusyDialog.open();
			});
			oServiceModel.attachRequestCompleted(function () {
				if (view._oBusyDialog) {
					view._oBusyDialog.close();
				}
			});
			oServiceModel.fireRequestSent();
			var that = this;
			oServiceModel.read(relPath, {
				success: function (oData, oResponse) {

					that.getView().getModel("ProductKeyModel").setData(oData.results);
					//Close Busy Dialog
					if (view._oBusyDialog) {
						view._oBusyDialog.close();
					}

				},
				error: function (oError) {
					//Close Busy Dialog
					if (view._oBusyDialog) {
						view._oBusyDialog.close();
					}

				}
			});
		},

		onExecute: function (evt) {
			var test = "232";
			var aFilters = [];

			var CustomerVal = this.getView().byId("CustomerId").getValue();
			var ProductKeyVal = this.getView().byId("ProductKeyId").getValue();
			var StatusVal = this.getView().byId("StatusId").getValue();
			var ValidOn = this.getView().byId("ValidOnId").getValue();

			var oFilters = [new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.Contains, CustomerVal),
				new sap.ui.model.Filter("ProductKey", sap.ui.model.FilterOperator.Contains, ProductKeyVal),
				new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.Contains, StatusVal),
				new sap.ui.model.Filter("ValidOn", sap.ui.model.FilterOperator.Contains, ValidOn)
			];
			aFilters.push(oFilters[0]);

			var oServiceModel = this.getOwnerComponent().getModel();
			var that = this;
			oServiceModel.read("/RepositoryObjectSet", {
				filters: aFilters,
				success: function (oData, oResponse) {
					var SummaryTableModel = new sap.ui.model.json.JSONModel(oData.results);
					that.getView().setModel(SummaryTableModel, "SummaryTableModel");
				},
				error: function (oError) {
					//Close Busy Dialog
					/*if (view._oBusyDialog) {
						view._oBusyDialog.close();
					}*/

				}
			});

		},

		onpress: function (evt) {
			var oCtx = evt.getSource().getBindingContext("SummaryTableModel").getObject();
			this._oRouter.navTo("SplitAppView",{
					Customer : oCtx.Customer,
					ProductKey : oCtx.Product
			});
		},
		createViewSettingsDialog: function (sDialogFragmentName) {
			var oDialog = this._mViewSettingsDialogs[sDialogFragmentName];

			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(sDialogFragmentName, this);
				this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;

			}
			return oDialog;
		},

		handleSortButtonPressed: function () {
			this.createViewSettingsDialog("test.ZCUST_PROJ.view.Fragments.SortDialog").open();
		},


		handleSortDialogConfirm: function (oEvent) {
			var oTable = this.getView().byId("SummaryTableId"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				sPath,
				bDescending,
				aSorters = [];

			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));

			// apply the selected sort and group settings
			oBinding.sort(aSorters);
		},


		onToggleContextMenu: function (oEvent) {
			var oToggleButton = oEvent.getSource();
			if (oEvent.getParameter("pressed")) {
				oToggleButton.setTooltip("Disable Custom Context Menu");
				this.getView().byId("SummaryTableId").setContextMenu(new Menu({
					items: [
						new MenuItem({
							text: "{Name}"
						}),
						new MenuItem({
							text: "{ProductId}"
						})
					]
				}));
			} else {
				oToggleButton.setTooltip("Enable Custom Context Menu");
				this.getView().byId("SummaryTableId").destroyContextMenu();
			}
		}

	});
});