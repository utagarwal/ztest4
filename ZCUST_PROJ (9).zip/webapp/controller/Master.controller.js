sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("test.ZCUST_PROJ.controller.Master", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf test.ZCUST_PROJ.view.Master
		 */
		onInit: function () {
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.getRoute("SplitAppView").attachPatternMatched(this.onRouteMatched, this);
		},
		
		  onAfterRendering: function(){
			  this.getView().getParent().addStyleClass("masterStyle");
      },

		onpress: function () {
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("DefaultView");
		},

		onRouteMatched: function (oEvent) {
			var oArgs = oEvent.getParameter("arguments");
			this.customer = oArgs.Customer;
			this.productVal = oArgs.ProductKey;
			var aFilters = [];

			var oFilters = [new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.Contains, this.customer),
				new sap.ui.model.Filter("ProductKey", sap.ui.model.FilterOperator.Contains, this.productVal),
			];
			aFilters.push(oFilters);

		/*	var oServiceModel = this.getOwnerComponent().getModel();
			var that = this;
			oServiceModel.read("/RepositoryObjectSet", {
				filters: aFilters,
				success: function (oData, oResponse) {
					var ContractListModel = new sap.ui.model.json.JSONModel(oData.results);
					that.getView().setModel(ContractListModel, "ContractListModel");
					that.getView().byId("ContractListID").setSelectedItem(that.getView().byId("ContractListID").getItems()[0]);
					var oRouter = that.getOwnerComponent().getRouter();
					oRouter.navTo("detail", {
						Contract: oData.results[0].Contract
					});
				},
				error: function (oError) {

				}
			});*/
			var oRouter = this.getOwnerComponent().getRouter();
			//oRouter.navTo("detail");
			oRouter.navTo("detail", {
				Contract: "567890",
				Customer: this.customer,
				ProductKey: this.productVal

			});
		},

		onListItemSelect: function (evt) {
			var oCtx = evt.getSource().getBindingContext("ContractListModel").getObject();
			var oRouter = this.getOwnerComponent().getRouter();

			oRouter.navTo("detail", {
				Contract: oCtx.Contract,
				Customer: this.Customer,
				ProductKey: this.productVal

			});
		}

		/*	_onMasterMatched :  function() {
				this.getOwnerComponent().oListSelector.oWhenListLoadingIsDone.then(
					function (mParams) {
						if (mParams.list.getMode() === "None") {
							return;
						}
						var sObjectId = mParams.firstListitem.getBindingContext().getProperty("CustomerReturn");
						this.getRouter().navTo("object", {objectId : sObjectId}, true);
					}.bind(this),
					function (mParams) {
						if (mParams.error) {
							return;
						}
						this.getRouter().getTargets().display("detailNoObjectsAvailable");
					}.bind(this)
				);
			},*/

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf test.ZCUST_PROJ.view.Master
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf test.ZCUST_PROJ.view.Master
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf test.ZCUST_PROJ.view.Master
		 */
		//	onExit: function() {
		//
		//	}

	});

});