sap.ui.define([
	"test/ZCUST_PROJ/test/unit/controller/View1.controller"
], function () {
	"use strict";
});