sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("ZDS_CREATE_UPDATE_PRICE.controller.LandingPage", {
	// Methods calls start from here
		// This method is called when the app is initialized
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("LandingPage").attachPatternMatched(this._onObjectMatched, this);
		},

		// This method is called when the navigation happens from Main view to S1 View
		_onObjectMatched: function (oEvent) {
			// this.getView().byId("idMainTab").setVisible(false);
		//	this.onFilterSearch();
		},

		// This method is called when the user presses GO button at the filter bar
		onFilterSearch: function () {

			var action = this.getView().byId("ActionSelect").getSelectedKey();
			var productKey = this.getView().byId("idProductKey").getValue();
			var customer = this.getView().byId("idCustomer").getSelectedKey();
			var salesOrg = this.getView().byId("idSalesOrg").getSelectedKey();
			var distChannel = this.getView().byId("idDistributionChannel").getValue();
			var materialGroup = this.getView().byId("idMaterialGroup").getSelectedKey();
			var shipToCountry = this.getView().byId("idShipToCountry").getSelectedKey();
			var intentOfUse = this.getView().byId("idIntentOfUse").getValue();
			var validOn = this.getView().byId("idDatePicker").getValue();
			// *****************************************************************************
			// Start of code comment for mandatory fields validation on Initial screen
			// *****************************************************************************
			// *****************************************************************************

			var oAction = new sap.ui.model.Filter("BusUnit", sap.ui.model.FilterOperator.EQ, action);
			var oProductKey = new sap.ui.model.Filter("Vendor", sap.ui.model.FilterOperator.EQ, productKey);
			var oCustomer = new sap.ui.model.Filter("Vendor", sap.ui.model.FilterOperator.EQ, customer);
			var oSalesOrg = new sap.ui.model.Filter("FiscalYr", sap.ui.model.FilterOperator.EQ, salesOrg);
			var oDistChnl = new sap.ui.model.Filter("FiscalMnth", sap.ui.model.FilterOperator.EQ, distChannel);
			var oMatGrp = new sap.ui.model.Filter("Invoice", sap.ui.model.FilterOperator.EQ, materialGroup);
			var oShipToCnrty = new sap.ui.model.Filter("FiscalYr", sap.ui.model.FilterOperator.EQ, shipToCountry);
			var oIntntOfUse = new sap.ui.model.Filter("FiscalMnth", sap.ui.model.FilterOperator.EQ, intentOfUse);
			var oValidOn = new sap.ui.model.Filter("Invoice", sap.ui.model.FilterOperator.EQ, validOn);

			var aFilters = new Filter({
				filters: [
					oAction,
					oProductKey,
					oCustomer,
					oDistChnl,
					oSalesOrg,
					oShipToCnrty,
					oMatGrp,
					oIntntOfUse,
					oValidOn
				],
				and: true
			});

			// This method is called to enable the Busy Indicator while the logic gets processed
			this.showBusyIndicator(0);

			var oModel = this.getOwnerComponent().getModel();

			that = this;
			oModel.read("/ETY_INV_HDRSet", {
				success: function (oData) {
					if (oData.results.length === 0) {
						sap.m.MessageToast.show("No Records found.");
						that.getView().byId("idMainTab").setVisible(false);
						that.hideBusyIndicator();
						return;
					}
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("View2");

					//This method is called to disable the Busy Indicator
					that.hideBusyIndicator();
				},
				error: function (oError) {
					sap.m.MessageToast.show("Error occurred while fetching the details!");
					that.hideBusyIndicator();
				},
				filters: [aFilters]
			});
		},
		
		
/*----------------------------------------Product Key F4 Start----------------------------------------------------------------*/		
		onValueHelpProductKeyF4: function (oEvent) {

			this._oValueHelpProductKeyDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ProductKeyF4", this);
			this.getView().addDependent(this._oValueHelpProductKeyDialog);
			var oTable = this._oValueHelpProductKeyDialog.getTable();

			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/SHSM_M_MAT1M");
			}
			this._oValueHelpProductKeyDialog.update();
			this._oValueHelpProductKeyDialog.open();
		},
		onValueHelpProductKeyF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idProductKey");
			oInput.setValue(aTokens[0].getKey());
			oInput.setTooltip(aTokens[0].getText());
			this._oValueHelpProductKeyDialog.close();
		},
		onValueHelpProductKeyF4CancelPress: function () {
			this._oValueHelpProductKeyDialog.close();
		},
		onValueHelpProductKeyF4AfterClose: function () {
			this._oValueHelpProductKeyDialog.destroy();
		},
		onSearchProductKeyF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpProductKeyDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'matnr',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'matkg',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: true
			});

			oTable.getBinding("rows").filter(aFilters);
		},	
		
/*----------------------------------------Product Key F4 Start----------------------------------------------------------------*/	

/*----------------------------------------Customer  F4 Start----------------------------------------------------------------*/	
	onValueHelpCustomer: function (oEvent) {

			this._oValueHelpCustomerDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.CustomerF4", this);
			this.getView().addDependent(this._oValueHelpCustomerDialog);
			var oTable = this._oValueHelpCustomerDialog.getTable();

			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/I_Customer");
			}
			this._oValueHelpCustomerDialog.update();
			this._oValueHelpCustomerDialog.open();
		},
		onValueHelpCustomerF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idCustomer");
			oInput.setValue(aTokens[0].getKey());
			oInput.setTooltip(aTokens[0].getText());
			this._oValueHelpCustomerDialog.close();
		},
		onValueHelpCustomerF4CancelPress: function () {
			this._oValueHelpCustomerDialog.close();
		},
		onValueHelpCustomerF4AfterClose: function () {
			this._oValueHelpCustomerDialog.destroy();
		},
		onSearchCustomerF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpCustomerDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'Customer',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'Customer',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: true
			});

			oTable.getBinding("rows").filter(aFilters);
		},	

/*----------------------------------------Customer  F4 Start----------------------------------------------------------------*/	

/*----------------------------------------MaterialGroup  F4 Start----------------------------------------------------------------*/	

		onValueHelpMaterialGroup: function (oEvent) {  

			this._oValueHelpMaterialDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.MaterialGroupF4", this);
			this.getView().addDependent(this._oValueHelpMaterialDialog);
			var oTable = this._oValueHelpMaterialDialog.getTable();

			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/I_AdditionalMaterialGroup3");
			}
			this._oValueHelpMaterialDialog.update();
			this._oValueHelpMaterialDialog.open();
		},
		onValueHelpMaterialGroupF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idMaterialGroup");
			oInput.setValue(aTokens[0].getKey());
			oInput.setTooltip(aTokens[0].getText());
			this._oValueHelpMaterialDialog.close();
		},
		onValueHelpMaterialGroupF4CancelPress: function () {
			this._oValueHelpMaterialDialog.close();
		},
		onValueHelpMaterialGroupF4AfterClose: function () {
			this._oValueHelpMaterialDialog.destroy();
		},
		onSearchMaterialGroupF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpMaterialDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'MaterialGroup',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'MaterialGroup',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: true
			});

			oTable.getBinding("rows").filter(aFilters);
		},


/*----------------------------------------MaterialGroup  F4 End----------------------------------------------------------------*/	

/*----------------------------------------SalesOrg  F4 Start----------------------------------------------------------------*/	
		onValueHelpSalesOrg: function (oEvent) {  

			this._oValueHelpSalesOrgDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.SalesOrgF4", this);
			this.getView().addDependent(this._oValueHelpSalesOrgDialog);
			var oTable = this._oValueHelpSalesOrgDialog.getTable();

			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/C_SalesOrganizationVH");
			}
			this._oValueHelpSalesOrgDialog.update();
			this._oValueHelpSalesOrgDialog.open();
		},
		onValueHelpSalesOrgF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idSalesOrg");
			oInput.setValue(aTokens[0].getKey());
			oInput.setTooltip(aTokens[0].getText());
			this._oValueHelpSalesOrgDialog.close();
		},
		onValueHelpSalesOrgF4CancelPress: function () {
			this._oValueHelpSalesOrgDialog.close();
		},
		onValueHelpSalesOrgF4AfterClose: function () {
			this._oValueHelpSalesOrgDialog.destroy();
		},
		onSearchSalesOrgF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpSalesOrgDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'MaterialGroup',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'MaterialGroup',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: true
			});

			oTable.getBinding("rows").filter(aFilters);
		},
	
/*----------------------------------------SalesOrg  F4 End----------------------------------------------------------------*/	



/*----------------------------------------ShipToCountry  F4 Start----------------------------------------------------------------*/

	onValueHelpShipToCountry: function (oEvent) {  

			this._oValueHelpShipToCountryDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ShipToCountryF4", this);
			this.getView().addDependent(this._oValueHelpShipToCountryDialog);
			var oTable = this._oValueHelpShipToCountryDialog.getTable();

			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/I_Country");
			}
			this._oValueHelpShipToCountryDialog.update();
			this._oValueHelpShipToCountryDialog.open();
		},
		onValueHelpSalesOrgF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idShipToCountry");
			oInput.setValue(aTokens[0].getKey());
			oInput.setTooltip(aTokens[0].getText());
			this._oValueHelpShipToCountryDialog.close();
		},
		onValueHelpSalesOrgF4CancelPress: function () {
			this._oValueHelpShipToCountryDialog.close();
		},
		onValueHelpSalesOrgF4AfterClose: function () {
			this._oValueHelpShipToCountryDialog.destroy();
		},
		onSearchSalesOrgF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpShipToCountryDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'ShipToCountry',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'ShipToCountry',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: true
			});
			oTable.getBinding("rows").filter(aFilters);
		},

/*----------------------------------------ShipToCountry  F4 End----------------------------------------------------------------*/

/*----------------------------------------DistributionChannel  F4 Start----------------------------------------------------------------*/
	
	onValueHelpDistributionChannel: function (oEvent) {  

			this._oValueHelpDistributionChannelDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.DistributionChannelF4", this);
			this.getView().addDependent(this._oValueHelpDistributionChannelDialog);
			var oTable = this._oValueHelpDistributionChannelDialog.getTable();

			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/SHSM_H_MVKE");
			}
			this._oValueHelpDistributionChannelDialog.update();
			this._oValueHelpDistributionChannelDialog.open();
		},
		onValueHelpDistributionChannelF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idDistributionChannel");
			oInput.setValue(aTokens[0].getKey());
			oInput.setTooltip(aTokens[0].getText());
			this._oValueHelpDistributionChannelDialog.close();
		},
		onValueHelpDistributionChannelF4CancelPress: function () {
			this._oValueHelpDistributionChannelDialog.close();
		},
		onValueHelpDistributionChannelF4AfterClose: function () {
			this._oValueHelpDistributionChannelDialog.destroy();
		},
		onSearchDistributionChannelF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpDistributionChannelDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'DistributionChannel',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'DistributionChannel',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: true
			});
			oTable.getBinding("rows").filter(aFilters);
		},

/*----------------------------------------DistributionChannel  F4 End----------------------------------------------------------------*/


/*----------------------------------------IntentOfUse  F4 Start----------------------------------------------------------------*/
	
		onValueHelpIntentOfUse: function (oEvent) {  

			this._oValueHelpIntentOfUseDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.IntentOfUseF4", this);
			this.getView().addDependent(this._oValueHelpIntentOfUseDialog);
			var oTable = this._oValueHelpIntentOfUseDialog.getTable();

			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/ZCDSV_A_DS_USAGE_SEARCH_HELP");
			}
			this._oValueHelpIntentOfUseDialog.update();
			this._oValueHelpIntentOfUseDialog.open();
		},
		onValueHelpIntentOfUseF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idIntentOfUse");
			oInput.setValue(aTokens[0].getKey());
			oInput.setTooltip(aTokens[0].getText());
			this._oValueHelpIntentOfUseDialog.close();
		},
		onValueHelpIntentOfUseF4CancelPress: function () {
			this._oValueHelpIntentOfUseDialog.close();
		},
		onValueHelpIntentOfUseF4AfterClose: function () {
			this._oValueHelpIntentOfUseDialog.destroy();
		},
		onSearchIntentOfUseF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpIntentOfUseDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'IntentOfUse',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'IntentOfUse',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: true
			});
			oTable.getBinding("rows").filter(aFilters);
		},
	
/*----------------------------------------IntentOfUse  F4 End----------------------------------------------------------------*/
		

	

	
		
		toView2Press: function(){
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("PriceApproval");
		}
	});
});