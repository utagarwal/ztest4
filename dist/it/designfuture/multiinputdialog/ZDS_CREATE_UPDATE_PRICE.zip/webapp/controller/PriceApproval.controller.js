sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("ZDS_CREATE_UPDATE_PRICE.controller.PriceApproval", {

		onInit: function () {
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.getRoute("PriceApproval").attachPatternMatched(this.onRouteMatched, this);

		},

		colExtendedName: function (colData) {
			var rescrModel = this.getView().getModel("i18n").getResourceBundle();
			rescrModel.getText("column.conditionrecord");
			for (var b = 0; b < colData.length; b++) {
				if (colData[b] === "ConditionRecord") {
					colData[b] = rescrModel.getText("column.conditionrecord");
				} else if (colData[b] === "ConditionType") {
					colData[b] = rescrModel.getText("column.conditiontype");
				} else if (colData[b] === "CountryKey") {
					colData[b] = rescrModel.getText("column.countrykey");
				} else if (colData[b] === "CustomerPriceGroup") {
					colData[b] = rescrModel.getText("column.customerpricegroup");
				} else if (colData[b] === "DistributionChannel") {
					colData[b] = rescrModel.getText("column.distributionchannel");
				} else if (colData[b] === "DocumentCurrency") {
					colData[b] = rescrModel.getText("column.documentcurrency");
				} else if (colData[b] === "MaterialGroup3") {
					colData[b] = rescrModel.getText("column.materialgroup");
				} else if (colData[b] === "MaterialNumber") {
					colData[b] = rescrModel.getText("column.materialnumber");
				} else if (colData[b] === "ProcessStatus") {
					colData[b] = rescrModel.getText("column.processstatus");
				} else if (colData[b] === "ProfitCenter") {
					colData[b] = rescrModel.getText("column.profitcenter");
				} else if (colData[b] === "ReleaseStatus") {
					colData[b] = rescrModel.getText("column.releasestatus");
				} else if (colData[b] === "SalesOrganization") {
					colData[b] = rescrModel.getText("column.salesorganzation");
				} else if (colData[b] === "SoldToParty") {
					colData[b] = rescrModel.getText("column.soldtoparty");
				} else if (colData[b] === "UserIndicator") {
					colData[b] = rescrModel.getText("column.userindicator");
				} else if (colData[b] === "ValidFrom") {
					colData[b] = rescrModel.getText("column.validfrom");
				} else if (colData[b] === "ValidTo") {
					colData[b] = rescrModel.getText("column.validto");
				} else if (colData[b] === "VendorAccountNumber") {
					colData[b] = rescrModel.getText("column.vendoraccountnumber");
				}

			}
			return colData;

		},

		onConditionTableDynamicBinding: function (ColData, TableData) {

			for (var n = 0; n < TableData.length; n++) {
				var data = TableData.results[n].ConditionType;
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MM.dd.yyyy"
				});
				var dateObjDate = oDateFormat.format(data);
				TableData.results[n].ConditionType = dateObjDate;
			}

			var TableDataResult = TableData.results.reduce(function (r, a) {
				r[a.TableName] = r[a.TableName] || [];
				r[a.TableName].push(a);
				return r;
			}, Object.create(null));

			var arrayUniqueData = [];
			var uniqueDataSplit = TableDataResult;
			for (var key in uniqueDataSplit) {
				for (var t = 0; t < ColData.results.length; t++) {
					if (key === ColData.results[t].TableName) {
						var allData = {};
						allData.TableName = key;
						allData.DataTable = uniqueDataSplit[key];
						allData.ColData = ColData.results[t];
						arrayUniqueData.push(allData);
					}
				}
			}

			var uniqueTableColArray = arrayUniqueData;
			for (var k = 0; k < uniqueTableColArray.length; k++) {
				var table1 = new sap.m.Table({
					id: "table_" + k,
					growing: true,
					alternateRowColors: true
				}).addStyleClass("sapUiLargeMarginTop");

				var ModelDynValId = "Model" + k;
				var ModelDynVal = "Model" + k;

				var tableDataCol = [];
				var p1 = uniqueTableColArray[k].ColData;
				for (var key1 in p1) {
					if (p1.hasOwnProperty(key1)) {
						if (p1[key1] === true && key1 !== "CommentLine") {
							tableDataCol.push(key1);
						}
					}
				}
				tableDataCol.push("Comments");
				var bindModel = ModelDynValId + ">/";
				var bindModelTable = ModelDynValId + ">";

				var cols = new sap.m.ColumnListItem({
					vAlign: "Middle"
				});

				var tableDataRow = tableDataCol;
				for (var l = 0; l < tableDataRow.length; l++) {
					if (tableDataRow[l] !== "Comments") {
						var label = new sap.m.Label({
							text: "{" + bindModelTable + tableDataRow[l] + "}",
							wrapping: true
						});
						cols.addCell(label);
					} else if (tableDataRow[l] === "Comments") {
						var input = new sap.m.Input({
							value: "{" + bindModelTable + "CommentLine}",
							liveChange: function (oEvent) {
								oEvent.getSource().setValueState("None");
							},
							width: "85%"
						}).addStyleClass("marginTableBtn");
						var button = new sap.m.Button({
							icon: "sap-icon://notification-2",
							press: function (oEvent) {
								var commentVal = oEvent.getSource().getParent().getItems()[0].getValue();
								this.oInput = oEvent.getSource().getParent().getItems()[0];
								if (!this.oSubmitDialog) {
									this.oSubmitDialog = new sap.m.Dialog({
										type: sap.m.DialogType.Message,
										contentWidth: "30%",
										title: "Confirm",
										content: [
											new sap.m.TextArea("CommentValId", {
												width: "100%",
												value: commentVal,
												placeholder: "Add comment (required)",
											})
										],
										beginButton: new sap.m.Button({
											type: sap.m.ButtonType.Emphasized,
											text: "Submit",
											enabled: true,
											press: function (evt) {
												this.oSubmitDialog.close();
												this.oInput.setValue(sap.ui.getCore().byId("CommentValId").getValue());
												if (this.oInput.getValueState() === "Error") {
													if (sap.ui.getCore().byId("CommentValId").getValue() !== "") {
														this.oInput.setValueState("None");
													}
												}
											}.bind(this)
										})
									});
								}
								sap.ui.getCore().byId("CommentValId").setValue(commentVal);
								this.oSubmitDialog.open();
							}.bind(this)
						});

						var Hbox = new sap.m.HBox();
						Hbox.addItem(input);
						Hbox.addItem(button);
						cols.addCell(Hbox);
					}
				}

				tableDataCol = this.colExtendedName(tableDataCol);
				for (var i = 0; i < tableDataCol.length; i++) {
					var oColumn;
					oColumn = new sap.m.Column("col" + i + k, {
						header: new sap.m.Label({
							text: tableDataCol[i],
							wrapping: true
						})
					});
					table1.addColumn(oColumn);
				}

				ModelDynVal = new JSONModel();
				ModelDynVal.setData(uniqueTableColArray[k].DataTable);
				table1.setModel(ModelDynVal, ModelDynValId);
			//	table1.setGrowingThreshold(200);
			//	table1.setGrowing(true);
			//	table1.setGrowingScrollToLoad(true);
				table1.bindAggregation("items", bindModel, cols);
				table1.setHeaderText(uniqueTableColArray[k].TableName);
				table1.setMode("MultiSelect");
				this.getView().byId("TableBox").addItem(table1);
			}
		},

		onDisableItems: function () {
			var tableList = this.getView().byId("TableBox").getItems();
			for (var i = 0; i < tableList.length; i++) {
				var tableItems = this.getView().byId("TableBox").getItems()[i].getItems();
				for (var j = 0; j < tableItems.length; j++) {
					var tableItemCells = tableList[i].getItems()[j].getCells();
					for (var k = 0; k < tableItemCells.length; k++) {
						if (!tableItemCells[k].getItems) {
							if (tableItemCells[k].getText() === "Y6" || tableItemCells[k].getText() === "Y5") {
								tableList[i].getItems()[j].getMultiSelectControl(true).setVisible(false);
								tableItemCells[tableItemCells.length - 1].getItems()[0].setEnabled(false);
								tableItemCells[tableItemCells.length - 1].getItems()[1].setEnabled(false);
							} else {
								tableList[i].getItems()[j].getMultiSelectControl(true).setVisible(true);
								tableItemCells[tableItemCells.length - 1].getItems()[0].setEnabled(true);
								tableItemCells[tableItemCells.length - 1].getItems()[1].setEnabled(true);
							}
						}

					}
				}
				/*	for (var j = 0; j < tableColumns.length; j++) {
						if (tableColumns[j].getHeader().getText() === "Approved") {
							for (var k = 0; k < tableList[i].getItems().length; k++) {
								tableList[i].getItems()[k].getCells()[j].getItems()[0].setValueState("None");
							}
						}
					}*/
			}
		},

		onResetTableSelection: function () {
			var tableList = this.getView().byId("TableBox").getItems();
			for (var i = 0; i < tableList.length; i++) {
				var tableColumns = this.getView().byId("TableBox").getItems()[i].getColumns();
				for (var j = 0; j < tableColumns.length; j++) {
					if (tableColumns[j].getHeader().getText() === "Comments") {
						for (var k = 0; k < tableList[i].getSelectedItems().length; k++) {
							tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].setValueState("None");
						}
					}
				}
			}
		},
		
			onpress: function () {
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("LandingPage");
		},

		onApvRejPress: function (evt) {
			if (!this.oApvRejConfirm) {
				this.oApvRejConfirm = sap.ui.xmlfragment("test.ZCUST_PROJ.view.Fragments.ApproveRejectConfirmDialog", this);
				this.getView().addDependent(this.oApvRejConfirm);
			}
			this.oApvRejConfirm.open();
		},

		onClose: function () {
			if (!this.oApvRejConfirm) {
				this.oApvRejConfirm = sap.ui.xmlfragment("test.ZCUST_PROJ.view.Fragments.ApproveRejectConfirmDialog", this);
			}
			this.oApvRejConfirm.close();
		},

		onRejectBtnPress: function () {
			var tableList = this.getView().byId("TableBox").getItems();
			var msgErrFlag = false;
			for (var i = 0; i < tableList.length; i++) {
				var tableColumns = this.getView().byId("TableBox").getItems()[i].getColumns();
				for (var j = 0; j < tableColumns.length; j++) {
					if (tableColumns[j].getHeader().getText() === "Comments") {
						for (var k = 0; k < tableList[i].getSelectedItems().length; k++) {
							if (tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].getValue() === "" && tableList[i].getSelectedItems()[k].getCells()[
									j].getItems()[0].getEnabled() === true) {
								tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].setValueState("Error");
								msgErrFlag = true;
							} else {
								tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].setValueState("None");
							}
						}
					}
				}

			}
			if (msgErrFlag === true) {
				sap.m.MessageToast.show("Please enter comments for rejected Items");
			}
		},

		onSubmitDialogPress: function () {

		},

		onRouteMatched: function (oEvent) {
			var columnData = [{
				//	ActionSelected: false,
				CommentLine: true,
				ConditionRecord: true,
				ConditionType: true,
				ConditionDescription: true,
				DistributionChannel: true,
				MaterialNumber: true,
				ProcessStatus: true,
				ProfitCenter: true,
				SalesOrganization: false,
				TableName: "A924",
				__metadata: ""
			}, {
				//		ActionSelected: true,
				CommentLine: true,
				ConditionRecord: true,
				ConditionType: true,
				//		ConditionDescription: true,
				DistributionChannel: false,
				MaterialNumber: true,
				ProcessStatus: true,
				//		ProfitCenter: true,
				SalesOrganization: true,
				TableName: "A925",
				__metadata: ""
			}];

			var date = new Date();

			var tableData = [{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38327",
				ConditionType: date,
				ConditionDescription: "Channel Margin",
				DistributionChannel: "52",
				MaterialNumber: "Pixel 4A",
				ProcessStatus: "Y3",
				ProfitCenter: "",
				SalesOrganization: "CA03",
				TableName: "A924",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38328",
				ConditionType: date,
				ConditionDescription: "Channel Margin 1",
				DistributionChannel: "55",
				MaterialNumber: "Pixel",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA03N",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38329",
				ConditionType: date,
				ConditionDescription: "Channel Margin 2",
				DistributionChannel: "53",
				MaterialNumber: "Pixel 4B",
				ProcessStatus: "Y2",
				ProfitCenter: "",
				SalesOrganization: "CA02",
				TableName: "A924",
				__metadata: ""
			}, 
			{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},
			{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},
			{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},
			{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},
			{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},
			{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},
				{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},
			{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},
			{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},
			{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},
			{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},
			{
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y5",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			}, {
				ActionSelected: "",
				CommentLine: "",
				ConditionRecord: "38321",
				ConditionType: date,
				ConditionDescription: "Channel Margin 3",
				DistributionChannel: "54",
				MaterialNumber: "Pixel 4C",
				ProcessStatus: "Y1",
				ProfitCenter: "",
				SalesOrganization: "CA04",
				TableName: "A925",
				__metadata: ""
			},];

			var dataSet1Col = {};
			dataSet1Col.results = columnData;

			var dataSet2Data = {};
			dataSet2Data.results = tableData;

			this.onConditionTableDynamicBinding(dataSet1Col, dataSet2Data);
			this.onDisableItems();
			var oArgs = oEvent.getParameter("arguments");
			this.customer = oArgs.Customer;
			this.productVal = oArgs.ProductKey;
			this.contractVal = oArgs.Contract;
			var aFilters = [];

			var oFilters = [new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.Contains, this.customer),
				new sap.ui.model.Filter("ProductKey", sap.ui.model.FilterOperator.Contains, this.productVal),
				new sap.ui.model.Filter("Contract", sap.ui.model.FilterOperator.Contains, this.contractVal)
			];
			aFilters.push(oFilters);

			this.getView().byId("CustomerDisplayID").setText(this.customer);
			this.getView().byId("ProductDisplayID").setText(this.productVal);

			/*	var oServiceModel = this.getOwnerComponent().getModel();
				var that = this;
				oServiceModel.read("/RepositoryObjectSet", {
					filters: aFilters,
					success: function (oData, oResponse) {
						var ContractListModel = new sap.ui.model.json.JSONModel(oData.results);
						that.getView().setModel(ContractListModel, "ContractListModel");
						that.getView().byId("ContractListID").setSelectedItem(that.getView().byId("ContractListID").getItems()[0]);
						var oRouter = that.getOwnerComponent().getRouter();
						oRouter.navTo("detail", {
							Contract: oData.results[0].Contract
						});
					},
					error: function (oError) {

					}
				});*/
		},

		onApproveBtnPress: function (oEvent) {
			var btnText = oEvent.getSource().getText();
			var Flag;
			if (btnText === "Approve") {
				Flag = "Approve";
			} else {
				Flag = "Reject";
			}
			var tables = this.getView().byId("TableBox").getItems();
			var payload = [];
			var dataPresent = false;
			var allDataSelected = true;
			var tableData = [];
			for (var i = 0; i < tables.length; i++) {
				var tableSelectedData = this.getView().byId("TableBox").getItems()[i].getSelectedContexts();
				if (tableSelectedData.length > 0) {
					dataPresent = true;
					var objData = {};
					for (var k = 0; k < tableSelectedData.length; k++) {
						var selData = tableSelectedData[k].getObject();
						if (selData.ProcessStatus === "Y3" || selData.ProcessStatus === "Y5") {
							var selStatusData = {};
							selStatusData.ConditionRecord = selData.ConditionRecord;
							selStatusData.TableName = selData.TableName;

							tableData.push(selStatusData);
						}
					}
					objData.tableData = tableData;
					objData.TableName = this.getView().byId("TableBox").getItems()[i].getHeaderText();
					payload.push(objData);
				} else {
					allDataSelected = false;
				}
			}
			if (!dataPresent) {
				sap.m.MessageToast.show("No Item Selected");
				return false;
			}
			if (!allDataSelected) {
				sap.m.MessageToast.show("Please select all the Items to continue");
				return false;
			}

			var oServiceModel = this.getOwnerComponent().getModel();
			var view = this.getView();
			var payLoadData = {};
			payLoadData.Customer = this.customer;
			payLoadData.Product = this.productVal;
			payLoadData.Contract = this.contractVal;
			payLoadData.Flag = Flag;
			payLoadData.tableData = payload;

			var ty = [];
			var tr = {}, te = {};
			tr.a = "name1";
			tr.b = "r1";
			te.a = "name1";
			te.b = "r1";
			ty.push(tr);
			ty.push(te);

			var ErrorMesssagesModel = new JSONModel();
			ErrorMesssagesModel.setData(ty);
		

			if (!this.oErrorMsgsDailog) {
				this.oErrorMsgsDailog = sap.ui.xmlfragment("test.ZCUST_PROJ.view.Fragments.ErrorMessages", this);
				this.getView().addDependent(this.oErrorMsgsDailog);
			}
			this.oErrorMsgsDailog.open();
			this.oErrorMsgsDailog.setModel(ErrorMesssagesModel, "ErrorMesssagesModel");

			//Busy Dialog
			/*	oServiceModel.attachRequestSent(function () {
					if (!view._oBusyDialog) {
						view._oBusyDialog = new sap.m.BusyDialog({
							title: "Please wait. . . "
						});
						view.addDependent(view._oBusyDialog);
					}
					view._oBusyDialog.open();
				});
				oServiceModel.attachRequestCompleted(function () {
					if (view._oBusyDialog) {
						view._oBusyDialog.close();
					}
				});
				oServiceModel.fireRequestSent();
				var that = this;
				oServiceModel.create("/RepositoryObjectSet", payload, {
					success: function (data, oResponse) {
						sap.m.MessageToast.show("success");
						that.onLoadProjects();
						that.onItemSelect();

					},
					error: function (oError) {
						//Close Busy Dialog

						if (view._oBusyDialog) {
							view._oBusyDialog.close();
						}
						that.createNewErrorLog(oError, "Error"); //display error messages

					}
				});*/
		},

		/*onRejectBtnPress: function () {

		},*/

		selectAllitems: function () {
			var tableList = this.getView().byId("TableBox").getItems();
			for (var i = 0; i < tableList.length; i++) {
				tableList[i].selectAll();
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf test.ZCUST_PROJ.view.Detail
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf test.ZCUST_PROJ.view.Detail
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf test.ZCUST_PROJ.view.Detail
		 */
		//	onExit: function() {
		//
		//	}

	});

});