sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter"
], function (Controller, JSONModel, Filter) {
	"use strict";

	return Controller.extend("ZDS_CREATE_UPDATE_PRICE.controller.PriceApproval", {

		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("PriceApproval").attachPatternMatched(this.onRouteMatched, this);
			this.rescrModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		// This method is called when the user presses GO button at the filter bar
		onFilterSearch: function () {
		/*	var action = this.getView().byId("ActionSelect").getSelectedKey();
			var productKey = this.getView().byId("idProductKey").getValue();
			var customer = this.getView().byId("idCustomer").getSelectedKey();
			// var salesOrg = this.getView().byId("idSalesOrg").getSelectedKey();
			// var distChannel = this.getView().byId("idDistributionChannel").getValue();
			var materialGroup = this.getView().byId("idMaterialGroup").getSelectedKey();
			// var shipToCountry = this.getView().byId("idShipToCountry").getSelectedKey();
			// var intentOfUse = this.getView().byId("idIntentOfUse").getValue();
			var validOn = this.getView().byId("idDatePicker").getValue();
			// *****************************************************************************
			// Start of code comment for mandatory fields validation on Initial screen
			// *****************************************************************************
			// *****************************************************************************
			//http://sapdapp74.dev7.gcp.sapcloud.goog:8000/sap/opu/odata/sap/ZDS_CREATE_UPDATE_PRICE_SRV/PriceRecords?$filter=Customer eq '6010000000'
			//and ProductKey eq 'PIXEL 4A' and MaterialGroup3 eq '001' and ValidOn eq datetime'2021-11-22T00%3A00%3A00' and SalesOrganization eq 'US03'
			//and Scenario eq 'CREATE'&$format=json
			action = "CREATE";
			customer = "6010000000";
			productKey = "PIXEL 4A";
			materialGroup = "001";
			validOn = "01.12.2021";
			var salesOrg = "US03";
			var distChannel = "51";
			var oAction = new sap.ui.model.Filter("Scenario", sap.ui.model.FilterOperator.EQ, action);
			var oProductKey = new sap.ui.model.Filter("ProductKey", sap.ui.model.FilterOperator.EQ, productKey);
			var oCustomer = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, customer);
			var oSalesOrg = new sap.ui.model.Filter("SalesOrganization", sap.ui.model.FilterOperator.EQ, salesOrg);
			var oDistChnl = new sap.ui.model.Filter("DistributionChannel", sap.ui.model.FilterOperator.EQ, distChannel);
			var oMatGrp = new sap.ui.model.Filter("MaterialGroup3", sap.ui.model.FilterOperator.EQ, materialGroup);
			// var oShipToCnrty = new sap.ui.model.Filter("FiscalYr", sap.ui.model.FilterOperator.EQ, shipToCountry);
			// var oIntntOfUse = new sap.ui.model.Filter("FiscalMnth", sap.ui.model.FilterOperator.EQ, intentOfUse);
			var oValidOn = new sap.ui.model.Filter("ValidOn", sap.ui.model.FilterOperator.EQ, validOn);

			var aFilters = new Filter({
				filters: [
					oAction,
					oProductKey,
					oCustomer,
					oDistChnl,
					oSalesOrg,
					// oShipToCnrty,
					oMatGrp,
					// oIntntOfUse,
					oValidOn
				],
				and: true
			});*/

			// This method is called to enable the Busy Indicator while the logic gets processed
			// this.showBusyIndicator(0);
			var aFilters = this.getView().getModel("FilterModel").getData();
			var oModel = this.getOwnerComponent().getModel();

			var that = this;
			oModel.read("/PriceRecords", {
				success: function (oData) {
					if (oData.results.length === 0) {
						sap.m.MessageToast.show("No Records found.");
						that.getView().byId("idMainTab").setVisible(false);
						that.hideBusyIndicator();
						return;
					}
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("View2");

					//This method is called to disable the Busy Indicator
					// that.hideBusyIndicator();
				},
				error: function (oError) {
					sap.m.MessageToast.show("Error occurred while fetching the details!");
					that.hideBusyIndicator();
				},
				filters: [aFilters]
			});
		},
		colExtendedName: function (colData) {
			this.rescrModel = this.getView().getModel("i18n").getResourceBundle();
			for (var b = 0; b < colData.length; b++) {
				if (colData[b] === "ConditionRecord") {
					colData[b] = this.rescrModel.getText("ConditionRecord");
				} else if (colData[b] === "ConditionType") {
					colData[b] = this.rescrModel.getText("ConditionType");
				} else if (colData[b] === "CountryKey") {
					colData[b] = this.rescrModel.getText("CountryKey");
				} else if (colData[b] === "CustomerPriceGroup") {
					colData[b] = this.rescrModel.getText("CustomerPriceGroup");
				} else if (colData[b] === "DistributionChannel") {
					colData[b] = this.rescrModel.getText("DistributionChannel");
				} else if (colData[b] === "DocumentCurrency") {
					colData[b] = this.rescrModel.getText("DocumentCurrency");
				} else if (colData[b] === "MaterialGroup3") {
					colData[b] = this.rescrModel.getText("MaterialGroup");
				} else if (colData[b] === "MaterialNumber") {
					colData[b] = this.rescrModel.getText("MaterialNumber");
				} else if (colData[b] === "ProcessStatus") {
					colData[b] = this.rescrModel.getText("ProcessStatus");
				} else if (colData[b] === "ProfitCenter") {
					colData[b] = this.rescrModel.getText("ProfitCenter");
				} else if (colData[b] === "ReleaseStatus") {
					colData[b] = this.rescrModel.getText("ReleaseStatus");
				} else if (colData[b] === "SalesOrganization") {
					colData[b] = this.rescrModel.getText("SalesOrganzation");
				} else if (colData[b] === "SoldToParty") {
					colData[b] = this.rescrModel.getText("SoldToParty");
				} else if (colData[b] === "UserIndicator") {
					colData[b] = this.rescrModel.getText("UserIndicator");
				} else if (colData[b] === "ValidFrom") {
					colData[b] = this.rescrModel.getText("ValidFrom");
				} else if (colData[b] === "ValidTo") {
					colData[b] = this.rescrModel.getText("ValidTo");
				} else if (colData[b] === "VendorAccountNumber") {
					colData[b] = this.rescrModel.getText("VendorAccountNumber");
				}
			}
			return colData;
		},

		onConditionTableDynamicBinding: function (TableData, ColData) {
			this.getView().byId("TableBox").destroyItems();
			for (var n = 0; n < TableData.results.length; n++) {

				var validToDate = TableData.results[n].ValidTo;
				var validFromDate = TableData.results[n].ValidFrom;
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MM.dd.yyyy"
				});
				var dateObjValidFrom = oDateFormat.format(validToDate);
				var dateObjValidTo = oDateFormat.format(validFromDate);
				TableData.results[n].ValidTo = dateObjValidFrom;
				TableData.results[n].ValidFrom = dateObjValidTo;
			}
			var TableDataResult = TableData.results.reduce(function (r, a) {
				r[a.TableName] = r[a.TableName] || [];
				r[a.TableName].push(a);
				return r;
			}, Object.create(null));

			var arrayUniqueData = [];
			var uniqueDataSplit = TableDataResult;
			for (var key in uniqueDataSplit) {
				for (var t = 0; t < ColData.results.length; t++) {
					if (key === ColData.results[t].TableName) {
						var allData = {};
						allData.TableName = key;
						allData.TableDescription = ColData.results[t].TableDescription;
						allData.DataTable = uniqueDataSplit[key];
						allData.ColData = ColData.results[t];
						arrayUniqueData.push(allData);
					}
				}
			}

			var uniqueTableColArray = arrayUniqueData;
			for (var k = 0; k < uniqueTableColArray.length; k++) {
				var table1 = new sap.m.Table({
					id: "table_" + k,
					growing: true,
					alternateRowColors: true
				}).addStyleClass("sapUiLargeMarginTop");

				var ModelDynValId = "Model" + k;
				var ModelDynVal = "Model" + k;

				var tableDataCol = [];
				var p1 = uniqueTableColArray[k].ColData;
				for (var key1 in p1) {
					if (p1.hasOwnProperty(key1)) {
						if ((p1[key1] === true && key1 !== "Amount" && key1 !== "NewValidTo" && key1 !== "NewValidFrom" && key1 !== "ContractID")) {
							tableDataCol.push(key1);
						}
					}
				}
				tableDataCol.push("Amount");
				tableDataCol.push("NewValidTo");
				tableDataCol.push("NewValidFrom");
				tableDataCol.push("ContractID");
				ModelDynVal = new JSONModel();
				ModelDynVal.setData(uniqueTableColArray[k].DataTable);
				table1.setModel(ModelDynVal, ModelDynValId);

				var bindModel = ModelDynValId + ">/";
				var bindModelTable = ModelDynValId + ">";

				var cols = new sap.m.ColumnListItem({
					vAlign: "Middle"
				});
				var tableDataRow = tableDataCol;
				for (var l = 0; l < tableDataRow.length; l++) {
					if (tableDataRow[l] === "Amount") {
						var input = new sap.m.Input({
							value: "{" + bindModelTable + "Amount}",
							liveChange: function (oEvent) {
								oEvent.getSource().setValueState("None");
							},
						}).addStyleClass("marginTableBtn");
						cols.addCell(input);
					} else if (tableDataRow[l] === "NewValidTo") {
						var input = new sap.m.DatePicker({
							value: "{" + bindModelTable + "NewValidTo}",
							displayFormat: "MM.dd.yyyy",
							valueFormat: "MM.dd.yyyy"
						}).addStyleClass("marginTableBtn");
						cols.addCell(input);
					} else if (tableDataRow[l] === "NewValidFrom") {
						var input = new sap.m.DatePicker({
							value: "{" + bindModelTable + "NewValidFrom}",
							displayFormat: "MM.dd.yyyy",
							valueFormat: "MM.dd.yyyy"
						}).addStyleClass("marginTableBtn");
						cols.addCell(input);
					} else if (tableDataRow[l] === "ContractID") {
						var input = new sap.m.Input({
							value: "{" + bindModelTable + "ContractID}",
							liveChange: function (oEvent) {
								oEvent.getSource().setValueState("None");
							}
						}).addStyleClass("marginTableBtn");
						cols.addCell(input);
					} else {
						var label = new sap.m.Label({
							text: "{" + bindModelTable + tableDataRow[l] + "}",
							wrapping: true
						});

						cols.addCell(label);
					}
				}
				tableDataCol = this.colExtendedName(tableDataCol);
				for (var i = 0; i < tableDataCol.length; i++) {
					var oColumn = new sap.m.Column("col" + i + k, {
						header: new sap.m.Text({
							text: tableDataCol[i],
							wrapping: true
						})
					});
					table1.addColumn(oColumn);
				}
				table1.bindAggregation("items", bindModel, cols);
				var headerText = uniqueTableColArray[k].TableName + " - " + uniqueTableColArray[k].TableDescription;
				table1.setHeaderText(headerText);
				table1.setGrowingThreshold(200);
				table1.setGrowing(true);
				table1.setGrowingScrollToLoad(true);
				// table1.attachUpdateFinished(function(oEvent) {
				// this.onDisableItems();
				// }.bind(this));
				table1.setMode("MultiSelect");
				this.getView().byId("TableBox").addItem(table1);
			}
		},

		onApvRejPress: function (evt) {
			this.btnAction = evt.getSource().getText();
			var btnText = this.btnAction;
			var tables = this.getView().byId("TableBox").getItems();
			var dataPresent = false;
			var allDataSelected = true;
			for (var i = 0; i < tables.length; i++) {
				var tableSelectedData = this.getView().byId("TableBox").getItems()[i].getSelectedContexts();
				if (tableSelectedData.length > 0) {
					dataPresent = true;
				} else {
					allDataSelected = false;
				}
				if (tableSelectedData.length !== tables[i].getItems().length) {
					allDataSelected = false;
				}
			}
			if (!dataPresent) {
				sap.m.MessageToast.show("No Item Selected");
				return false;
			}
			// this.onClearComments();
			if (btnText === "Reject") {
				var rejectFlag = this.onRejectBtnPress();
				if (rejectFlag === false) {
					return false;
				}
			}
			if (!this.oApvRejConfirm) {
				this.oApvRejConfirm = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ApproveRejectConfirmDialog", this);
				this.getView().addDependent(this.oApvRejConfirm);
			}
			this.oApvRejConfirm.open();
		},

		onClose: function () {
			if (!this.oApvRejConfirm) {
				this.oApvRejConfirm = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ApproveRejectConfirmDialog", this);
			}
			this.oApvRejConfirm.close();
		},

		// onDisableItems: function() {
		// var tableList = this.getView().byId("TableBox").getItems();
		// var disableApvRejBtn = true;
		// for (var i = 0; i < tableList.length; i++) {
		// var tableItems = this.getView().byId("TableBox").getItems()[i].getItems();
		// for (var j = 0; j < tableItems.length; j++) {
		// var tableItemCells = tableList[i].getItems()[j].getCells();
		// for (var k = 0; k < tableItemCells.length; k++) {
		// if (!tableItemCells[k].getItems) {
		// if (tableItemCells[k].getText() === "Y3" || tableItemCells[k].getText() === "Y5") {
		// tableList[i].getItems()[j].getMultiSelectControl(true).setVisible(true);
		// tableItemCells[tableItemCells.length - 1].getItems()[0].setEnabled(true);
		// tableItemCells[tableItemCells.length - 1].getItems()[1].setEnabled(true);
		// disableApvRejBtn = false;
		// // break;
		// } else {
		// tableList[i].getItems()[j].getMultiSelectControl(true).setVisible(false);
		// tableItemCells[tableItemCells.length - 1].getItems()[0].setEnabled(false);
		// tableItemCells[tableItemCells.length - 1].getItems()[1].setEnabled(false);
		// }
		// }
		// }
		// }
		// }
		// if (disableApvRejBtn === true) {
		// this.getView().byId("ApproveBtnID").setEnabled(false);
		// this.getView().byId("RejectBtnID").setEnabled(false);
		// } else {
		// this.getView().byId("ApproveBtnID").setEnabled(true);
		// this.getView().byId("RejectBtnID").setEnabled(true);
		// }
		// },

		onResetTableSelection: function () {
			var tableList = this.getView().byId("TableBox").getItems();
			for (var i = 0; i < tableList.length; i++) {
				var tableColumns = this.getView().byId("TableBox").getItems()[i].getColumns();
				for (var j = 0; j < tableColumns.length; j++) {
					if (tableColumns[j].getHeader().getText() === "Comments") {
						for (var k = 0; k < tableList[i].getSelectedItems().length; k++) {
							tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].setValueState("None");
						}
					}
				}
			}
		},

		onRejectBtnPress: function () {
			var tableList = this.getView().byId("TableBox").getItems();
			var msgErrFlag = false;
			for (var i = 0; i < tableList.length; i++) {
				var tableColumns = this.getView().byId("TableBox").getItems()[i].getColumns();
				for (var j = 0; j < tableColumns.length; j++) {
					if (tableColumns[j].getHeader().getText() === "Comments") {
						for (var k = 0; k < tableList[i].getSelectedItems().length; k++) {
							if (tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].getValue() === "" && tableList[i].getSelectedItems()[k].getCells()[
									j].getItems()[0].getEnabled() === true) {
								tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].setValueState("Error");
								msgErrFlag = true;
							} else {
								tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].setValueState("None");
							}
						}
					}
				}
			}
			if (msgErrFlag === true) {
				sap.m.MessageToast.show("Please enter comments for rejected Items");
				return false;
			}
		},
		onClearComments: function () {
			var tableList = this.getView().byId("TableBox").getItems();
			for (var i = 0; i < tableList.length; i++) {
				var tableColumns = this.getView().byId("TableBox").getItems()[i].getColumns();
				for (var j = 0; j < tableColumns.length; j++) {
					if (tableColumns[j].getHeader().getText() === "Comments") {
						for (var k = 0; k < tableList[i].getSelectedItems().length; k++) {
							tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].setValueState("None");
						}
					}
				}

			}
		},
		onSubmitDialogPress: function () {

		},

		onRouteMatched: function (oEvent) {
			var oArgs = oEvent.getParameter("arguments");
			this.customer = oArgs.Customer;
			this.productVal = oArgs.Material;
			this.contractVal = oArgs.Contract;
			if (oArgs.Contract === "No Contract Id") {
				this.contractVal = "";
			}
			this.onConditionTableSrvCall(this.customer, this.productVal, this.contractVal);
		},
		onSelectContract: function (ContractId) {
			this.onConditionTableSrvCall(this.customer, this.productVal, ContractId);
		},
		onConditionTableSrvCall: function (Customer, Material, ContractId) {
			var action = "CREATE";
			var customer = "6010000000";
			var productKey = "PIXEL 4A";
			var materialGroup = "001";
			var validOn = "01.12.2021";
			var salesOrg = "US03";
			var distChannel = "51";
			var oAction = new sap.ui.model.Filter("Scenario", sap.ui.model.FilterOperator.EQ, action);
			var oProductKey = new sap.ui.model.Filter("ProductKey", sap.ui.model.FilterOperator.EQ, productKey);
			var oCustomer = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, customer);
			var oSalesOrg = new sap.ui.model.Filter("SalesOrganization", sap.ui.model.FilterOperator.EQ, salesOrg);
			var oDistChnl = new sap.ui.model.Filter("DistributionChannel", sap.ui.model.FilterOperator.EQ, distChannel);
			var oMatGrp = new sap.ui.model.Filter("MaterialGroup3", sap.ui.model.FilterOperator.EQ, materialGroup);
			// var oShipToCnrty = new sap.ui.model.Filter("FiscalYr", sap.ui.model.FilterOperator.EQ, shipToCountry);
			// var oIntntOfUse = new sap.ui.model.Filter("FiscalMnth", sap.ui.model.FilterOperator.EQ, intentOfUse);
			var oValidOn = new sap.ui.model.Filter("ValidOn", sap.ui.model.FilterOperator.EQ, validOn);

			var aFilters = new Filter({
				filters: [
					oAction,
					oProductKey,
					oCustomer,
					oDistChnl,
					oSalesOrg,
					// oShipToCnrty,
					oMatGrp,
					// oIntntOfUse,
					oValidOn
				],
				and: true
			});

			// This method is called to enable the Busy Indicator while the logic gets processed
			// this.showBusyIndicator(0);

			var oModel = this.getOwnerComponent().getModel();

			var that = this;
			oModel.read("/PriceRecords", {
				filters: [aFilters],
				success: function (oData, oResponse) {
					var conditionTableData = oData;
					var oServiceColModel = that.getOwnerComponent().getModel();
					var that1 = that;
					oServiceColModel.read("/ConditionFieldsIdentification", {
						success: function (data, oResponse) {
							if (oData.results.length !== 0) {
								var ContractListModel = new sap.ui.model.json.JSONModel(oData.results);
								that1.getView().setModel(ContractListModel, "ContractListModel");
								that1.onConditionTableDynamicBinding(conditionTableData, data);
								// that1.onDisableItems();
							} else {

								var oRouter = that1.getOwnerComponent().getRouter();
								oRouter.navTo("MessagePage");
							}
						},
						error: function (oError) {

						}
					});
				},
				error: function (oError) {

				}
			});
		},
		onApproveRejBtnPress: function () {
			this.onClose();
			var btnText = this.btnAction;
			var Action;
			var tables = this.getView().byId("TableBox").getItems();
			var tableData = [];
			for (var m = 0; m < tables.length; m++) {
				var tableSelectedData = this.getView().byId("TableBox").getItems()[m].getSelectedContexts();
				if (tableSelectedData.length > 0) {
					for (var k = 0; k < tableSelectedData.length; k++) {
						var selData = tableSelectedData[k].getObject();
						var selStatusData = {};
						selStatusData.ConditionRecord = selData.ConditionRecord;
						selStatusData.TableName = selData.TableName;
						selStatusData.ProductKey = selData.ProductKey;
						selStatusData.MaterialGroup3 = selData.MaterialGroup3;
						selStatusData.ValidOn = "\/Date(20210113000000)\/"; //"01.13.2021";
						selStatusData.Customer = selData.Customer;
						selStatusData.SalesOrganization = selData.SalesOrganization;
						selStatusData.DistributionChannel = selData.DistributionChannel;
						selStatusData.ShipToCountry = selData.ShipToCountry;
						// selStatusData.IntentOfUse = selData.IntentOfUse;
						selStatusData.CallBapi = false;
						selStatusData.Scenario = "CREATE";
						// selStatusData.CreateFlag = selData.CreateFlag;
						selStatusData.ConditionType = selData.ConditionType;
						selStatusData.ProcessStatus = selData.ProcessStatus;
						selStatusData.Unit = selData.Unit;
						selStatusData.Amount = selData.Amount;
						selStatusData.PricingUnit = selData.PricingUnit;
						selStatusData.DocumentCurrency = selData.DocumentCurrency;
						selStatusData.ContractID = selData.ContractID;
						selStatusData.ValidTo = "\/Date(99990114000000)\/"; //selData.ValidTo;
						selStatusData.ValidFrom = "\/Date(20200112000000)\/"; //selData.ValidFrom;
						selStatusData.NewValidTo = "\/Date(20210114000000)\/"; //selData.NewValidTo;
						selStatusData.NewValidFrom = "\/Date(20210113000000)\/"; //selData.NewValidFrom;

						selStatusData.EmailFlag = "";

						tableData.push(selStatusData);
					}
				}
			}
			if (btnText === this.rescrModel.getText("Approve")) {
				Action = "/Approve_Records";
			} else {
				Action = "/Reject_Records";
			}
			var oServiceModel = this.getOwnerComponent().getModel();
			//Busy Dialog
			var view = this.getView();
			oServiceModel.attachRequestSent(function () {
				if (!view._oBusyDialog) {
					view._oBusyDialog = new sap.m.BusyDialog({
						title: "Please wait. . . "
					});
					view.addDependent(view._oBusyDialog);
				}
				view._oBusyDialog.open();
			});
			oServiceModel.attachRequestCompleted(function () {
				if (view._oBusyDialog) {
					view._oBusyDialog.close();
				}
			});
			oServiceModel.fireRequestSent();
			var that = this;

			var oModel = oServiceModel;

			var oEmp1 = {
				"EmployeeId": "0000000014",
				"FirstName": "Laura",
				"LastName": "Hahn"
			};
			var oEmp2 = {
				"EmployeeId": "0000000015",
				"FirstName": "Matthias",
				"LastName": "Müller"
			};
			var batchChanges = [];
			// for (var i = 0; i < tableData.length; i++) {
			// batchChanges.push(oModel.createBatchOperation("/PriceRecords", "POST", tableData[i]));
			// }

			oServiceModel.setDeferredGroups(["batchcall"]);
			for (var i = 0; i < tableData.length; i++) {
				// var mParameter = {

				// urlParameters: tableData[i],
				// groupId: "batchcall",
				// success: function(innerdata) {
				// var de = "123";
				// //This success handler will only be called if batch support is enabled.
				// //If multiple batch groups are submitted the handlers will be called for every batch group.

				// }
				// // error: function(oError) {

				// // }

				var singleentry = {};
				singleentry.properties = tableData[i];

				singleentry.changeSetId = "changeset " + i;
				this.getOwnerComponent().getModel().create("/PriceRecords", tableData[i], {
					groupId: "batchcall"
				});
			}
			oServiceModel.submitChanges({
				groupId: "batchcall", //Same as the batch group id used previously
				success: function (oData) {

					sap.m.MessageToast.show("Success");
				}.bind(this),
				error: function (oError) {
					sap.m.MessageToast.show("Error");
				}
			});
			// oServiceModel.submitChanges(mParameter);
			// oModel.addBatchChangeOperations(batchChanges);

			// oModel.submitBatch(function(oData) {
			// oModel.refresh();
			// var allSuccess = true;
			// var conflictRecordsPresent = false;
			// var conflictRecords = [];
			// var errorRecords = [];
			// for (var j = 0; j < (oData.__batchResponses.length) - 1; j++) {
			// var recordData = {};
			// var errorData = {};
			// if (oData.__batchResponses[j].__changeResponses[0].data.IsSuccess !== "X" && oData.__batchResponses[j].__changeResponses[0].data
			// .Message !== "") {
			// errorData.ConditionRecord = oData.__batchResponses[j].__changeResponses[0].data.ConditionRecord;
			// errorData.TableName = oData.__batchResponses[j].__changeResponses[0].data.TableName;
			// errorData.Message = oData.__batchResponses[j].__changeResponses[0].data.Message;
			// errorRecords.push(errorData);
			// allSuccess = false;
			// }
			// if (oData.__batchResponses[j].__changeResponses[0].data.IsAlreadyApproved === "X") {
			// recordData.ConditionRecord = oData.__batchResponses[j].__changeResponses[0].data.ConditionRecord;
			// recordData.ConditionType = oData.__batchResponses[j].__changeResponses[0].data.ConditionType;
			// recordData.TableName = oData.__batchResponses[j].__changeResponses[0].data.TableName;
			// var validToDate = oData.__batchResponses[j].__changeResponses[0].data.ValidTo;
			// var validFromDate = oData.__batchResponses[j].__changeResponses[0].data.ValidFrom;
			// var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// pattern: "MM.dd.yyyy"
			// });
			// recordData.ValidTo = oDateFormat.format(validToDate);
			// recordData.ValidFrom = oDateFormat.format(validFromDate);
			// conflictRecords.push(recordData);
			// conflictRecordsPresent = true;
			// }
			// }
			// if (allSuccess === false && errorRecords.length !== 0) {
			// var ErrorMesssagesModel = new JSONModel();
			// ErrorMesssagesModel.setData(errorRecords);

			// if (!that.oErrorMsgsDailog) {
			// that.oErrorMsgsDailog = sap.ui.xmlfragment("ZDS_BSP_APRVPRC.view.Fragments.ErrorMessages", that);
			// that.getView().addDependent(that.oErrorMsgsDailog);
			// }
			// that.oErrorMsgsDailog.open();
			// that.oErrorMsgsDailog.setModel(ErrorMesssagesModel, "ErrorMesssagesModel");
			// }
			// if (conflictRecordsPresent === true) {
			// var ConflictRecordsModel = new JSONModel();
			// ConflictRecordsModel.setData(conflictRecords);

			// if (!that.oConflictRecordsDailog) {
			// that.oConflictRecordsDailog = sap.ui.xmlfragment("ZDS_BSP_APRVPRC.view.Fragments.ConflictRecords", that);
			// that.getView().addDependent(that.oConflictRecordsDailog);
			// }
			// that.oConflictRecordsDailog.open();
			// that.oConflictRecordsDailog.setModel(ConflictRecordsModel, "ConflictRecordsModel");
			// }
			// if (btnText === this.rescrModel.getText("Approve") && allSuccess && !conflictRecordsPresent) {
			// var oRouter = that.getOwnerComponent().getRouter();
			// oRouter.navTo("SummaryScreen");
			// } else {
			// that.onConditionTableSrvCall(that.customer, that.productVal, that.contractVal);
			// }
			// sap.m.MessageToast.show(this.rescrModel.getText("Success"));
			// }.bind(this),
			// function(err) {
			// alert("Error occurred ");
			// });
		},
		// onApproveRejBtnPress: function() {
		// this.onClose();
		// var btnText = this.btnAction;
		// var Action;

		// var tables = this.getView().byId("TableBox").getItems();
		// var tableData = [];
		// for (var i = 0; i < tables.length; i++) {
		// var tableSelectedData = this.getView().byId("TableBox").getItems()[i].getSelectedContexts();
		// if (tableSelectedData.length > 0) {
		// for (var k = 0; k < tableSelectedData.length; k++) {
		// var selData = tableSelectedData[k].getObject();
		// if (selData.ProcessStatus === "Y3" || selData.ProcessStatus === "Y5") {
		// var selStatusData = {};
		// selStatusData.ConditionRecord = selData.ConditionRecord;
		// selStatusData.TableName = selData.TableName;
		// selStatusData.CommentLine = selData.CommentLine;
		// selStatusData.ValidTo = selData.ValidTo;
		// selStatusData.ValidFrom = selData.ValidFrom;
		// if (btnText === "Approve") {
		// selStatusData.IsAlreadyApproved = "";
		// selStatusData.Flag = "";
		// selStatusData.ConditionType = selData.ConditionType;
		// }
		// tableData.push(selStatusData);
		// }
		// }
		// }
		// }
		// if (btnText === "Approve") {
		// Action = "/Approve_Records";
		// } else {
		// Action = "/Reject_Records";
		// }
		// var oServiceModel = this.getOwnerComponent().getModel();
		// //Busy Dialog
		// var view = this.getView();
		// oServiceModel.attachRequestSent(function() {
		// if (!view._oBusyDialog) {
		// view._oBusyDialog = new sap.m.BusyDialog({
		// title: "Please wait. . . "
		// });
		// view.addDependent(view._oBusyDialog);
		// }
		// view._oBusyDialog.open();
		// });
		// oServiceModel.attachRequestCompleted(function() {
		// if (view._oBusyDialog) {
		// view._oBusyDialog.close();
		// }
		// });
		// oServiceModel.fireRequestSent();
		// var that = this;
		// //Set deferred groups and create Function Imports
		// oServiceModel.setDeferredGroups(["batchFunctionImport"]);
		// for (var i = 0; i < tableData.length; i++) {
		// oServiceModel.callFunction(Action, {
		// method: "POST",
		// batchGroupId: "batchFunctionImport",
		// changeSetId: i,
		// urlParameters: tableData[i]
		// });
		// }
		// oServiceModel.callFunction("/Email_Trigger", {
		// method: "POST",
		// batchGroupId: "batchFunctionImport",
		// changeSetId: tableData.length
		// });

		// //Submitting the function import batch call
		// oServiceModel.submitChanges({
		// batchGroupId: "batchFunctionImport", //Same as the batch group id used previously
		// success: function(oData) {
		// var allSuccess = true;
		// var conflictRecordsPresent = false;
		// var conflictRecords = [];
		// var errorRecords = [];
		// for (var j = 0; j < (oData.__batchResponses.length) - 1; j++) {
		// var recordData = {};
		// var errorData = {};
		// if (oData.__batchResponses[j].__changeResponses[0].data.IsSuccess !== "X" && oData.__batchResponses[j].__changeResponses[0].data
		// .Message !== "") {
		// errorData.ConditionRecord = oData.__batchResponses[j].__changeResponses[0].data.ConditionRecord;
		// errorData.TableName = oData.__batchResponses[j].__changeResponses[0].data.TableName;
		// errorData.Message = oData.__batchResponses[j].__changeResponses[0].data.Message;
		// errorRecords.push(errorData);
		// allSuccess = false;
		// }
		// if (oData.__batchResponses[j].__changeResponses[0].data.IsAlreadyApproved === "X") {
		// recordData.ConditionRecord = oData.__batchResponses[j].__changeResponses[0].data.ConditionRecord;
		// recordData.ConditionType = oData.__batchResponses[j].__changeResponses[0].data.ConditionType;
		// recordData.TableName = oData.__batchResponses[j].__changeResponses[0].data.TableName;
		// var validToDate = oData.__batchResponses[j].__changeResponses[0].data.ValidTo;
		// var validFromDate = oData.__batchResponses[j].__changeResponses[0].data.ValidFrom;
		// var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
		// pattern: "MM.dd.yyyy"
		// });
		// recordData.ValidTo = oDateFormat.format(validToDate);
		// recordData.ValidFrom = oDateFormat.format(validFromDate);
		// conflictRecords.push(recordData);
		// conflictRecordsPresent = true;
		// }
		// }
		// if (allSuccess === false && errorRecords.length !== 0) {
		// var ErrorMesssagesModel = new JSONModel();
		// ErrorMesssagesModel.setData(errorRecords);

		// if (!that.oErrorMsgsDailog) {
		// that.oErrorMsgsDailog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ErrorMessages", that);
		// that.getView().addDependent(that.oErrorMsgsDailog);
		// }
		// that.oErrorMsgsDailog.open();
		// that.oErrorMsgsDailog.setModel(ErrorMesssagesModel, "ErrorMesssagesModel");
		// }
		// if (conflictRecordsPresent === true) {
		// var ConflictRecordsModel = new JSONModel();
		// ConflictRecordsModel.setData(conflictRecords);

		// if (!that.oConflictRecordsDailog) {
		// that.oConflictRecordsDailog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ConflictRecords", that);
		// that.getView().addDependent(that.oConflictRecordsDailog);
		// }
		// that.oConflictRecordsDailog.open();
		// that.oConflictRecordsDailog.setModel(ConflictRecordsModel, "ConflictRecordsModel");
		// }
		// // oData.__batchResponses[0].__changeResponses[0].data.IsSuccess
		// if (btnText === "Approve" && allSuccess && !conflictRecordsPresent) {
		// var oRouter = that.getOwnerComponent().getRouter();
		// oRouter.navTo("SummaryScreen");
		// } else {
		// that.onConditionTableSrvCall(that.customer, that.productVal, that.contractVal);
		// }
		// sap.m.MessageToast.show("Success");
		// }.bind(this),
		// error: function(oError) {
		// sap.m.MessageToast.show("Error");
		// }
		// });
		// },

		selectAllitems: function () {
			var tableList = this.getView().byId("TableBox").getItems();
			for (var i = 0; i < tableList.length; i++) {
				tableList[i].selectAll();
			}
		},
		onCloseErrorDialog: function () {
			if (!this.oErrorMsgsDailog) {
				this.oErrorMsgsDailog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ErrorMessages", this);
			}
			this.oErrorMsgsDailog.close();
			this.onConditionTableSrvCall(this.customer, this.productVal, this.contractVal);
		},
		onAprvConflictBtnPress: function (evt) {
				var btnText = evt.getSource().getText();
				if (!this.oConflictRecordsDailog) {
					this.oConflictRecordsDailog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ConflictRecords", this);
				}
				this.oConflictRecordsDailog.close();
				var conflictRecordData = this.oConflictRecordsDailog.getModel("ConflictRecordsModel").getData();
				for (var i = 0; i < conflictRecordData.length; i++) {
					conflictRecordData[i].IsAlreadyApproved = "X";
					conflictRecordData[i].CommentLine = "";
					if (btnText === "Yes") {
						conflictRecordData[i].Flag = "Y";
					} else {
						conflictRecordData[i].Flag = "N";
					}
				}

				// this.onConditionTableSrvCall(this.customer, this.productVal, this.contractVal);
				var oServiceModel = this.getOwnerComponent().getModel();
				//Busy Dialog
				var view = this.getView();
				oServiceModel.attachRequestSent(function () {
					if (!view._oBusyDialog) {
						view._oBusyDialog = new sap.m.BusyDialog({
							title: "Please wait. . . "
						});
						view.addDependent(view._oBusyDialog);
					}
					view._oBusyDialog.open();
				});
				oServiceModel.attachRequestCompleted(function () {
					if (view._oBusyDialog) {
						view._oBusyDialog.close();
					}
				});
				oServiceModel.fireRequestSent();
				var that = this;
				//Set deferred groups and create Function Imports
				oServiceModel.setDeferredGroups(["batchFunctionImport"]);
				for (var i = 0; i < conflictRecordData.length; i++) {
					oServiceModel.callFunction("/Approve_Records", {
						method: "POST",
						batchGroupId: "batchFunctionImport",
						changeSetId: i,
						urlParameters: conflictRecordData[i]
					});
				}
				oServiceModel.callFunction("/Email_Trigger", {
					method: "POST",
					batchGroupId: "batchFunctionImport",
					changeSetId: conflictRecordData.length
				});

				//Submitting the function import batch call
				oServiceModel.submitChanges({
					batchGroupId: "batchFunctionImport", //Same as the batch group id used previously
					success: function (oData) {
							var allSuccess = true;
							var errorRecords = [];
							for (var j = 0; j < (oData.__batchResponses.length) - 1; j++) {
								var recordData = {};
								var errorData = {};
								if (oData.__batchResponses[j].__changeResponses[0].data.IsSuccess !== "X") {
									errorData.ConditionRecord = oData.__batchResponses[j].__changeResponses[0].data.ConditionRecord;
									errorData.TableName = oData.__batchResponses[j].__changeResponses[0].data.TableName;
									errorData.Message = oData.__batchResponses[j].__changeResponses[0].data.Message;
									errorRecords.push(errorData);
									allSuccess = false;
								}
							}
							if (allSuccess === false) {
								var ErrorMesssagesModel = new JSONModel();
								ErrorMesssagesModel.setData(errorRecords);

								if (!that.oErrorMsgsDailog) {
									that.oErrorMsgsDailog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ErrorMessages", that);
									that.getView().addDependent(that.oErrorMsgsDailog);
								}
								that.oErrorMsgsDailog.open();
								that.oErrorMsgsDailog.setModel(ErrorMesssagesModel, "ErrorMesssagesModel");
								that.onConditionTableSrvCall(that.customer, that.productVal, that.contractVal);
							} else {
								var oRouter = that.getOwnerComponent().getRouter();
								oRouter.navTo("SummaryScreen");
							}
						}
						// this.onConditionTableSrvCall(this.customer, this.productVal, this.contractVal);
				});
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf ZDS_CREATE_UPDATE_PRICE.viewApprovePriceDetail
			 */
			// onBeforeRendering: function() {
			//
			// },

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZDS_CREATE_UPDATE_PRICE.viewApprovePriceDetail
		 */
		// onAfterRendering: function() {
		//
		// },

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZDS_CREATE_UPDATE_PRICE.viewApprovePriceDetail
		 */
		// onExit: function() {
		//
		// }

	});

});