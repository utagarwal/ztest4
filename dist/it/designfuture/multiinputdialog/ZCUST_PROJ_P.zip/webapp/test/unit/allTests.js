sap.ui.define([
	"test/ZCUST_PROJ_P/test/unit/controller/View1.controller"
], function () {
	"use strict";
});