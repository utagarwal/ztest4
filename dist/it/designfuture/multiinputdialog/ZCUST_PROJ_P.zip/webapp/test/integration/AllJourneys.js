/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"test/ZCUST_PROJ_P/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"test/ZCUST_PROJ_P/test/integration/pages/View1",
	"test/ZCUST_PROJ_P/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "test.ZCUST_PROJ_P.view.",
		autoWait: true
	});
});