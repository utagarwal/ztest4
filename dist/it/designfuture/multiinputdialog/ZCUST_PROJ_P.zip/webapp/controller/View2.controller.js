sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("test.ZCUST_PROJ_P.controller.View2", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf test.ZCUST_PROJ_P.view.View2
		 */
		
			

			onInit: function () {
		//	var oRouter = this.getOwnerComponent().getRouter();
		//	oRouter.getRoute("detail").attachPatternMatched(this.onRouteMatched, this);

			var payload = [];
			var columnData = [{
				Field1: "Cond Type",
				Field2: "Sales org",
				Field3: "Sold to party",
				Field4: "SKU Type",
				Field5: "Unit",
				Field6: "Per",
				Field7: "Comments"

			}];

			var tableData = [{
				Cond_Type: "MSPRP",
				Sales_org: "Google LLC",
				SoldToParty: "Amazon US",
				SKU_Type: "Pristine",
				Unit: "EA",
				Per: "1",
				Comments: ""
			}, {
				Cond_Type: "MSPRP",
				Sales_org: "",
				SoldToParty: "Amazon US",
				SKU_Type: "Pristine",
				Unit: "EA",
				Per: "1",
				Comments: ""
			}];

			var columnData1 = [{
				Field1: "Sales org",
				Field2: "SKU Type",
				Field3: "Status",
				Field4: "Sold to party",
				Field5: "Unit",
				Field6: "Per",
				Field7: "Comments"
			}];

			var tableData1 = [{
				Sales_org: "Google LLC",
				SKU_Type: "Pristine",
				Status: "Approved",
				SoldToParty: "Amazon US",
				Unit: "EA",
				Per: "1",
				Comments: ""
			}, {
				Sales_org: "Google LLC",
				SKU_Type: "Pristine",
				Status: "Pending Approval",
				SoldToParty: "Walmart",
				Unit: "EA",
				Per: "1",
				Comments: ""

			}];

			var condTableName1 = "902";
			var condTableName2 = "910";

			var dataSet1 = {};
			dataSet1.condTableName1 = condTableName1;
			dataSet1.columnData = columnData;
			dataSet1.tableData = tableData;

			var dataSet2 = {};
			dataSet2.condTableName1 = condTableName2;
			dataSet2.columnData = columnData1;
			dataSet2.tableData = tableData1;

			var payload = [dataSet1, dataSet2];
			this.onConditionTableDynamicBinding(payload);
			this.onDisableItems();

		},
		
		toView1Press: function(){
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("TargetView1");
		},

		onConditionTableDynamicBinding: function (payload) {
			for (var k = 0; k < payload.length; k++) {
				var table1 = new sap.m.Table({
					id: "table_" + k,
					growing: true,
					alternateRowColors: true
				}).addStyleClass("sapUiLargeMarginTop");

				var ModelDynValId = "Model" + k;
				var ModelDynVal = "Model" + k;

				ModelDynVal = new JSONModel();
				ModelDynVal.setData(payload[k].tableData);
				table1.setModel(ModelDynVal, ModelDynValId);

				var arrayCol = [];
				var p = payload[k].columnData[0];
				for (var key in p) {
					if (p.hasOwnProperty(key)) {
						arrayCol.push(p[key]);
					}
				}

				var tableDataRow = [];
				var p1 = payload[k].tableData[0];
				for (var key1 in p1) {
					if (p.hasOwnProperty(key)) {
						tableDataRow.push(key1);
					}
				}

				for (var i = 0; i < arrayCol.length; i++) {
					var oColumn;
					if (arrayCol[i] === "Unit" || arrayCol[i] === "Per") {
						oColumn = new sap.m.Column("col" + i + k, {
							width: "3rem",
							header: new sap.m.Label({
								text: arrayCol[i]
							})
						});
					} else {
						oColumn = new sap.m.Column("col" + i + k, {
							header: new sap.m.Label({
								text: arrayCol[i]
							})
						});
					}
					table1.addColumn(oColumn);
				}

				var bindModel = ModelDynValId + ">/";
				var bindModelTable = ModelDynValId + ">";

				var cols = new sap.m.ColumnListItem({
					vAlign: "Middle"
				});
				for (var l = 0; l < tableDataRow.length; l++) {

					if (l === (tableDataRow.length - 1)) {
						var input = new sap.m.Input({
							value: "{" + bindModelTable + tableDataRow[l] + "}",
							liveChange: function (oEvent) {
								oEvent.getSource().setValueState("None");
							},
							width: "85%"
						}).addStyleClass("marginTableBtn");
						var button = new sap.m.Button({
							icon: "sap-icon://notification-2",
							press: function (oEvent) {
								var commentVal = oEvent.getSource().getParent().getItems()[0].getValue();
								this.oInput = oEvent.getSource().getParent().getItems()[0];
								if (!this.oSubmitDialog) {
									this.oSubmitDialog = new sap.m.Dialog({
										type: sap.m.DialogType.Message,
										contentWidth: "30%",
										title: "Confirm",
										content: [
											new sap.m.TextArea("CommentValId", {
												width: "100%",
												value: commentVal,
												placeholder: "Add comment (required)",
												/*liveChange: function (oEvent) {
													var sText = oEvent.getParameter("value");
													this.oSubmitDialog.getBeginButton().setEnabled(sText.length > 0);
												}.bind(this)*/
											})
										],
										beginButton: new sap.m.Button({
											type: sap.m.ButtonType.Emphasized,
											text: "Submit",
											enabled: true,
											press: function (evt) {
												this.oSubmitDialog.close();
												this.oInput.setValue(sap.ui.getCore().byId("CommentValId").getValue());
												if (this.oInput.getValueState() === "Error") {
													if (sap.ui.getCore().byId("CommentValId").getValue() !== "") {
														this.oInput.setValueState("None");
													}
												}
											}.bind(this)
										})
									});
								}
								sap.ui.getCore().byId("CommentValId").setValue(commentVal);
								this.oSubmitDialog.open();
							}.bind(this)
						});

						var Hbox = new sap.m.HBox();
						Hbox.addItem(input);
						Hbox.addItem(button);
						cols.addCell(Hbox);
					} else {
						var label = new sap.m.Label({
							text: "{" + bindModelTable + tableDataRow[l] + "}"
						});
						cols.addCell(label);
					}
				}

				table1.bindAggregation("items", bindModel, cols);
				table1.setHeaderText(payload[k].condTableName1);
				table1.setMode("MultiSelect");
				this.getView().byId("TableBox").addItem(table1);

			}
		},

		onDisableItems: function () {
			var tableList = this.getView().byId("TableBox").getItems();
			for (var i = 0; i < tableList.length; i++) {
				var tableItems = this.getView().byId("TableBox").getItems()[i].getItems();
				for (var j = 0; j < tableItems.length; j++) {
					var tableItemCells = tableList[i].getItems()[j].getCells();
					for (var k = 0; k < tableItemCells.length; k++) {
						if (!tableItemCells[k].getItems) {
							if (tableItemCells[k].getText() === "Approved") {
								tableList[i].getItems()[j].getMultiSelectControl(true).setVisible(false);
								tableItemCells[tableItemCells.length - 1].getItems()[0].setEnabled(false);
								tableItemCells[tableItemCells.length - 1].getItems()[1].setEnabled(false);
								break;
							} else {
								tableList[i].getItems()[j].getMultiSelectControl(true).setVisible(true);
								tableItemCells[tableItemCells.length - 1].getItems()[0].setEnabled(true);
								tableItemCells[tableItemCells.length - 1].getItems()[1].setEnabled(true);
							}
						}

					}
				}
				/*	for (var j = 0; j < tableColumns.length; j++) {
						if (tableColumns[j].getHeader().getText() === "Approved") {
							for (var k = 0; k < tableList[i].getItems().length; k++) {
								tableList[i].getItems()[k].getCells()[j].getItems()[0].setValueState("None");
							}
						}
					}*/
			}
		},

		onResetTableSelection: function () {
			var tableList = this.getView().byId("TableBox").getItems();
			for (var i = 0; i < tableList.length; i++) {
				var tableColumns = this.getView().byId("TableBox").getItems()[i].getColumns();
				for (var j = 0; j < tableColumns.length; j++) {
					if (tableColumns[j].getHeader().getText() === "Comments") {
						for (var k = 0; k < tableList[i].getSelectedItems().length; k++) {
							tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].setValueState("None");
						}
					}
				}
			}
		},

		onRejectBtnPress: function () {
			var tableList = this.getView().byId("TableBox").getItems();
			var msgErrFlag = false;
			for (var i = 0; i < tableList.length; i++) {
				var tableColumns = this.getView().byId("TableBox").getItems()[i].getColumns();
				for (var j = 0; j < tableColumns.length; j++) {
					if (tableColumns[j].getHeader().getText() === "Comments") {
						for (var k = 0; k < tableList[i].getSelectedItems().length; k++) {
							if (tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].getValue() === "" && tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].getEnabled() === true) {
								tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].setValueState("Error");
								msgErrFlag = true;
							} else {
								tableList[i].getSelectedItems()[k].getCells()[j].getItems()[0].setValueState("None");
							}
						}
					}
				}

			}
			if(	msgErrFlag === true){
				sap.m.MessageToast.show("Please enter comments for rejected Items");
			}
		},

		onSubmitDialogPress: function () {

		},

		onRouteMatched: function (oEvent) {
			var oArgs = oEvent.getParameter("arguments");
			this.customer = oArgs.Customer;
			this.productVal = oArgs.ProductKey;
			this.contractVal = oArgs.Contract;
			var aFilters = [];

			var oFilters = [new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.Contains, this.customer),
				new sap.ui.model.Filter("ProductKey", sap.ui.model.FilterOperator.Contains, this.productVal),
				new sap.ui.model.Filter("Contract", sap.ui.model.FilterOperator.Contains, this.contractVal)
			];
			aFilters.push(oFilters);

			this.getView().byId("CustomerDisplayID").setText(this.customer);
			this.getView().byId("ProductDisplayID").setText(this.productVal);

			/*	var oServiceModel = this.getOwnerComponent().getModel();
				var that = this;
				oServiceModel.read("/RepositoryObjectSet", {
					filters: aFilters,
					success: function (oData, oResponse) {
						var ContractListModel = new sap.ui.model.json.JSONModel(oData.results);
						that.getView().setModel(ContractListModel, "ContractListModel");
						that.getView().byId("ContractListID").setSelectedItem(that.getView().byId("ContractListID").getItems()[0]);
						var oRouter = that.getOwnerComponent().getRouter();
						oRouter.navTo("detail", {
							Contract: oData.results[0].Contract
						});
					},
					error: function (oError) {

					}
				});*/
		},

		onApproveBtnPress: function (oEvent) {
			var btnText = oEvent.getSource().getText();
			var Flag;
			if (btnText === "Approve") {
				Flag = "Approve";
			} else {
				Flag = "Reject";
			}
			var tables = this.getView().byId("TableBox").getItems();
			var payload = [];
			var dataPresent = false;
			var allDataSelected  = true;
			for (var i = 0; i < tables.length; i++) {
				var tableSelectedData = this.getView().byId("TableBox").getItems()[i].getSelectedContexts();
				if (tableSelectedData.length > 0) {
					dataPresent = true;
					var tableData = [];
					var objData = {};
					for (var k = 0; k < tableSelectedData.length; k++) {
						var selData = tableSelectedData[k].getObject();
						tableData.push(selData);
					}
					objData.tableData = tableData;
					objData.TableName = this.getView().byId("TableBox").getItems()[i].getHeaderText();
					payload.push(objData);
				}
				else{
					allDataSelected  = false;
				}
			}
				if (!dataPresent) {
				sap.m.MessageToast.show("No Item Selected");
				return false;
			}
			if(!allDataSelected){
				sap.m.MessageToast.show("Please select all the Items to continue");
				return false;
			}
		

			var oServiceModel = this.getOwnerComponent().getModel();
			var view = this.getView();
			var payLoadData = {};
			payLoadData.Customer = this.customer;
			payLoadData.Product = this.productVal;
			payLoadData.Contract = this.contractVal;
			payLoadData.Flag = Flag;
			payLoadData.tableData = payload;

			//Busy Dialog
			/*	oServiceModel.attachRequestSent(function () {
					if (!view._oBusyDialog) {
						view._oBusyDialog = new sap.m.BusyDialog({
							title: "Please wait. . . "
						});
						view.addDependent(view._oBusyDialog);
					}
					view._oBusyDialog.open();
				});
				oServiceModel.attachRequestCompleted(function () {
					if (view._oBusyDialog) {
						view._oBusyDialog.close();
					}
				});
				oServiceModel.fireRequestSent();
				var that = this;
				oServiceModel.create("/RepositoryObjectSet", payload, {
					success: function (data, oResponse) {
						sap.m.MessageToast.show("success");
						that.onLoadProjects();
						that.onItemSelect();

					},
					error: function (oError) {
						//Close Busy Dialog

						if (view._oBusyDialog) {
							view._oBusyDialog.close();
						}
						that.createNewErrorLog(oError, "Error"); //display error messages

					}
				});*/
		},

		/*onRejectBtnPress: function () {

		},*/

		selectAllitems: function () {
			var tableList = this.getView().byId("TableBox").getItems();
			for (var i = 0; i < tableList.length; i++) {
				tableList[i].selectAll();
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf test.ZCUST_PROJ.view.Detail
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf test.ZCUST_PROJ.view.Detail
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf test.ZCUST_PROJ.view.Detail
		 */
		//	onExit: function() {
		//
		//	}

	});

});