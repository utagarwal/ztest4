sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("test.ZCUST_PROJ_P.controller.View1", {
		onInit: function () {

		},
		
		selectScenarioRB: function(evt){
			if(evt.getSource().getSelectedButton().getText() ==="B2B"){
				this.getView().byId("B2BForm").setVisible(true);
				this.getView().byId("SparesForm").setVisible(false);
			}
			else 	if(evt.getSource().getSelectedButton().getText() ==="Spares"){
				this.getView().byId("B2BForm").setVisible(false);
				this.getView().byId("SparesForm").setVisible(true);
			}
		},
		
		toView2Press: function(){
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("View2");
		}
	});
});