sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessagePopoverItem",
	"sap/m/MessagePopover",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Controller, JSONModel, MessagePopoverItem, MessagePopover, Fragment, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("ZDS_CREATE_UPDATE_PRICE_SPARES.controller.LandingPage", {
		// Methods calls start from here
		// This method is called when the app is initialized
		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("LandingPage").attachPatternMatched(this._onObjectMatched, this);
			this.rescrModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();

			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "MM.dd.yyyy"
			});
			var currDateObjDate = oDateFormat.format(new Date());
			this.getView().byId("idDatePicker").setDateValue(new Date());
			// this.getView().byId("idProductKey").addvalidator(this._onMultiInputValidate);
		},
		onAfterRendering: function() {
			this.onActionChange();
			var that = this;
			["idCustomer", "idProductKey", "idDistributionChannel", "idSalesOrg"].forEach
				(function(item) {
					that.getView().byId(item).addValidator(that._onMultiInputValidate);
				});
			this.getView().byId("iStatus").setSelectedKeys(["Y2", "Y4"]);
		},

		// This method is called when the navigation happens from Main view to S1 View
		_onObjectMatched: function(oEvent) {
			// this.getView().byId("idMainTab").setVisible(false);
		},

		// This method is called when the user presses GO button at the filter bar
		onFilterSearch: function(oEvent) {

			var filterDataObj = {};

			filterDataObj.action = this.getView().byId("ActionSelect").getSelectedKey();
			filterDataObj.productKey = this.getView().byId("idProductKey").getValue().toUpperCase();
			if (filterDataObj.productKey === "" && this.getView().byId("idProductKey").getTokens().length !== 0) {
				filterDataObj.productKey = this.getView().byId("idProductKey").getTokens()[0].getKey();
			}
			filterDataObj.customer = this.getView().byId("idCustomer").getValue().toUpperCase();
			if (filterDataObj.customer === "" && this.getView().byId("idCustomer").getTokens().length !== 0) {
				filterDataObj.customer = this.getView().byId("idCustomer").getTokens()[0].getKey();
			}
			filterDataObj.salesOrg = this.getView().byId("idSalesOrg").getValue().toUpperCase();
			if (filterDataObj.salesOrg === "" && this.getView().byId("idSalesOrg").getTokens().length !== 0) {
				filterDataObj.salesOrg = this.getView().byId("idSalesOrg").getTokens()[0].getKey();
			}
			filterDataObj.distChannel = this.getView().byId("idDistributionChannel").getValue();
			if (filterDataObj.distChannel === "" && this.getView().byId("idDistributionChannel").getTokens().length !== 0) {
				filterDataObj.distChannel = this.getView().byId("idDistributionChannel").getTokens()[0].getKey();
			}
			filterDataObj.materialGroup = this.getView().byId("idMaterialGroup").getValue().toUpperCase();
			if (filterDataObj.materialGroup === "" && this.getView().byId("idMaterialGroup").getTokens().length !== 0) {
				filterDataObj.materialGroup = this.getView().byId("idMaterialGroup").getTokens()[0].getKey();
			}
			filterDataObj.shipToCountry = this.getView().byId("idShipToCountry").getValue().toUpperCase();
			if (filterDataObj.shipToCountry === "" && this.getView().byId("idShipToCountry").getTokens().length !== 0) {
				filterDataObj.shipToCountry = this.getView().byId("idShipToCountry").getTokens()[0].getKey();
			}
			filterDataObj.intentOfUse = this.getView().byId("idIntentOfUse").getValue();
			if (filterDataObj.intentOfUse === "" && this.getView().byId("idIntentOfUse").getTokens().length !== 0) {
				filterDataObj.intentOfUse = this.getView().byId("idIntentOfUse").getTokens()[0].getKey();
			}
			filterDataObj.validOn = this.getView().byId("idDatePicker").getValue();
			var statusLength = this.getView().byId("iStatus").getSelectedKeys().length;
			if (filterDataObj.productKey === "" || filterDataObj.customer === "" || filterDataObj.validOn === "" || filterDataObj.validOn ===
				null || statusLength === 0) {
				sap.m.MessageToast.show(this.rescrModel.getText("MandtFieldsMsg"));
				return false;
			}
			var oFilters = [];
			if (filterDataObj.action !== "") {
				oFilters.push(new sap.ui.model.Filter("Scenario", sap.ui.model.FilterOperator.EQ, filterDataObj.action));
			}
			if (filterDataObj.productKey !== "") {
				oFilters.push(new sap.ui.model.Filter("ProductKey", sap.ui.model.FilterOperator.EQ, filterDataObj.productKey));
			}
			if (filterDataObj.salesOrg !== "") {
				oFilters.push(new sap.ui.model.Filter("SalesOrganization", sap.ui.model.FilterOperator.EQ, filterDataObj.salesOrg));
			}
			if (filterDataObj.customer !== "") {
				oFilters.push(new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, filterDataObj.customer));
			}
			if (filterDataObj.distChannel !== "") {
				oFilters.push(new sap.ui.model.Filter("DistributionChannel", sap.ui.model.FilterOperator.EQ, filterDataObj.distChannel));
			}
			if (filterDataObj.materialGroup !== "") {
				oFilters.push(new sap.ui.model.Filter("MaterialGroup3", sap.ui.model.FilterOperator.EQ, filterDataObj.materialGroup));
			}
			if (filterDataObj.shipToCountry !== "") {
				oFilters.push(new sap.ui.model.Filter("ShipToCountry", sap.ui.model.FilterOperator.EQ, filterDataObj.shipToCountry));
			}
			if (filterDataObj.intentOfUse !== "") {
				oFilters.push(new sap.ui.model.Filter("IntentOfUse", sap.ui.model.FilterOperator.EQ, filterDataObj.intentOfUse));
			}
			if (filterDataObj.validOn !== "" || filterDataObj.validOn !== null) {
				oFilters.push(new sap.ui.model.Filter("ValidOn", sap.ui.model.FilterOperator.EQ, filterDataObj.validOn));
			}
			var cntrolStatus = this.getView().byId("iStatus");
			var that = this;
			var statusVal = cntrolStatus.getSelectedKeys();
			var statusArr = [];
			statusVal.forEach(function(item, index) {
				statusArr.push(new sap.ui.model.Filter("ProcessStatus", "EQ", item));
			});
			var statusFilter = new sap.ui.model.Filter({
				filters: statusArr,
				and: false
			});
			var filters = [];
			if (statusFilter.aFilters.length > 0) {
				oFilters.push(statusFilter);
			}
			var aFilters = new Filter({
				filters: oFilters,
				and: true
			});

			// var aSelectionSet = oEvent.getParameter("selectionSet");
			// var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
			// 			if (oControl.getValue){
			// 				if (oControl.getValue()) {
			// 					aResult.push(new Filter({
			// 						path: oControl.getName(),
			// 						operator: FilterOperator.EQ,
			// 						value1: oControl.getValue()
			// 					}));
			// 				}
			// 		} else if (oControl.getSelectedKey()) {
			// 			aResult.push(new Filter({
			// 				path: oControl.getName(),
			// 				operator: FilterOperator.Contains,
			// 				value1: oControl.getSelectedKey()
			// 			}));
			// 		}

			// 		return aResult;
			// 	},
			// 	[]);

			var oModelFilter = this.getView().getModel("FilterModel");
			var FilterData = {};
			FilterData.filterDataObj = filterDataObj;
			FilterData.aFilters = aFilters;
			oModelFilter.setData(FilterData);
			return true;
		},

		/*----------------------------------------Product Key F4 Start----------------------------------------------------------------*/
		// _onMultiInputValidate: function(oArgs) {
		// 	if (oArgs.suggestionObject) {
		// 		var oObject = oArgs.suggestionObject.getBindingContext().getObject(),
		// 			oToken = new sap.m.Token();
		// 		oToken.setKey(oObject.matnr);
		// 		oToken.setText(oObject.maktg + " (" + oObject.matnr + ")");
		// 		return oToken;
		// 	}
		// },
		_onMultiInputValidate: function(oArgs) {
			if (oArgs.suggestionObject) {
				var oObject = oArgs.suggestionObject.getBindingContext().getObject(),
					oToken = new sap.m.Token();
				var propertyName = oArgs.suggestionObject.getParent().getParent().getParent().getName();
				if (propertyName === "Customer") {
					oToken.setKey(oObject.Customer);
					oToken.setText(oObject.CustomerName + " (" + oObject.Customer + ")");
				} else if (propertyName === "ProductKey") {
					oToken.setKey(oObject.matnr);
					oToken.setText(oObject.maktg + " (" + oObject.matnr + ")");
				} else if (propertyName === "MaterialGroup3") {
					oToken.setKey(oObject.AdditionalMaterialGroup3);
					oToken.setText(oObject.AdditionalMaterialGroup3_Text + " (" + oObject.AdditionalMaterialGroup3 + ")");
				} else if (propertyName === "ShipToCountry") {
					oToken.setKey(oObject.Country);
					oToken.setText(oObject.Country_Text + " (" + oObject.Country + ")");
				} else if (propertyName === "SalesOrganization") {
					oToken.setKey(oObject.SalesOrganization);
					oToken.setText(oObject.SalesOrganization_Text + " (" + oObject.SalesOrganization + ")");
				} else if (propertyName === "DistributionChannel") {
					oToken.setKey(oObject.vtweg);
					oToken.setText(oObject.vtweg + " (" + oObject.vtext + ")");
				} else if (propertyName === "IntentOfUse") {
					oToken.setKey(oObject.IntentOfUse);
					oToken.setText(oObject.IntentOfUse + " (" + oObject.UsageText + ")");
				}

				return oToken;
			}

			return null;
		},
		onValueHelpProductKeyF4: function(oEvent) {
			this._oValueHelpProductKeyDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE_SPARES.view.fragment.ProductKeyF4", this);
			this.getView().addDependent(this._oValueHelpProductKeyDialog);
			var oTable = this._oValueHelpProductKeyDialog.getTable();

			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label: this.rescrModel.getText("ProductKey"),
					template: "matnr"
				}, {
					label: this.rescrModel.getText("ProductKeyDesc"),
					template: "maktg"
				}]
			});
			this._oValueHelpProductKeyDialog.getTable().setModel(oColModel2, "columns");

			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/ProductKeyVHelp");
			}
			// this._oValueHelpDialog.setTokens(this.getView().byId("idProductKey").getTokens());
			this._oValueHelpProductKeyDialog.update();
			this._oValueHelpProductKeyDialog.open();
		},
		onValueHelpProductKeyF4OkPress: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idProductKey");
			oInput.setTokens(aTokens);
			this._oValueHelpProductKeyDialog.close();
		},
		onValueHelpProductKeyF4CancelPress: function() {
			this._oValueHelpProductKeyDialog.close();
		},
		onValueHelpProductKeyF4AfterClose: function() {
			this._oValueHelpProductKeyDialog.destroy();
		},
		onSearchProductKeyF4: function(oEvent) {
			var aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function(aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);

			this._filterProductKeyTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},

		_filterProductKeyTable: function(oFilter) {
			var oTable = this._oValueHelpProductKeyDialog.getTable();
			//this._oValueHelpProductKeyDialog.getTableAsync().then(function (oTable) {
			if (oTable.bindRows) {
				oTable.getBinding("rows").filter(oFilter);
			}

			if (oTable.bindItems) {
				oTable.getBinding("items").filter(oFilter);
			}

			this._oValueHelpProductKeyDialog.update();
			// });
		},

		/*		onSearchProductKeyF4: function (oEvent) {
					var sVendorValue = oEvent.getParameters().newValue;
					var oTable = this._oValueHelpProductKeyDialog.getTable();
					var aFilters = new sap.ui.model.Filter({
						filters: [new sap.ui.model.Filter({
								path: 'matnr',
								operator: sap.ui.model.FilterOperator.Contains,
								value1: sVendorValue
							}),
							new sap.ui.model.Filter({
								path: 'maktg',
								operator: sap.ui.model.FilterOperator.EQ,
								value1: sVendorValue
							})
						],
						and: false
					});
					oTable.getBinding("rows").filter(aFilters);
				},*/

		/*----------------------------------------Product Key F4 Start----------------------------------------------------------------*/

		/*----------------------------------------Customer  F4 Start----------------------------------------------------------------*/
		onValueHelpCustomer: function(oEvent) {

			this._oValueHelpCustomerDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE_SPARES.view.fragment.CustomerF4", this);
			this.getView().addDependent(this._oValueHelpCustomerDialog);
			var oTable = this._oValueHelpCustomerDialog.getTable();
			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label: this.rescrModel.getText("Customer"),
					template: "Customer"
				}, {
					label: this.rescrModel.getText("CustomerNameText"),
					template: "CustomerName"
				}]
			});
			this._oValueHelpCustomerDialog.getTable().setModel(oColModel2, "columns");
			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/CustomerHelp");
			}
			this._oValueHelpCustomerDialog.update();
			this._oValueHelpCustomerDialog.open();
		},
		onValueHelpCustomerF4OkPress: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idCustomer");
			oInput.setTokens(aTokens);
			this._oValueHelpCustomerDialog.close();
		},
		onValueHelpCustomerF4CancelPress: function() {
			this._oValueHelpCustomerDialog.close();
		},
		onValueHelpCustomerF4AfterClose: function() {
			this._oValueHelpCustomerDialog.destroy();
		},

		onSuggestionItemSelectedCustomer: function(oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("idCustomer").setValue(sDescription);
		},

		onSearchCustomerF4: function(oEvent) {
			var aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function(aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);

			this._filterCustomerTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},
		_filterCustomerTable: function(oFilter) {
			var oTable = this._oValueHelpCustomerDialog.getTable();
			// this._oValueHelpCustomerDialog.getTableAsync().then(function (oTable) {
			if (oTable.bindRows) {
				oTable.getBinding("rows").filter(oFilter);
			}

			if (oTable.bindItems) {
				oTable.getBinding("items").filter(oFilter);
			}

			this._oValueHelpCustomerDialog.update();
			// });
		},
		/*----------------------------------------Customer  F4 Start----------------------------------------------------------------*/

		/*----------------------------------------MaterialGroup  F4 Start----------------------------------------------------------------*/

		onValueHelpMaterialGroup: function(oEvent) {

			this._oValueHelpMaterialDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE_SPARES.view.fragment.MaterialGroupF4", this);
			this.getView().addDependent(this._oValueHelpMaterialDialog);
			var oTable = this._oValueHelpMaterialDialog.getTable();
			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label: this.rescrModel.getText("AdditionalMaterialGroup"),
					template: "AdditionalMaterialGroup3"
				}, {
					label: this.rescrModel.getText("AdditionalMaterialGroupText"),
					template: "AdditionalMaterialGroup3_Text"
				}]
			});
			this._oValueHelpMaterialDialog.getTable().setModel(oColModel2, "columns");
			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/I_AdditionalMaterialGroup3");
			}
			this._oValueHelpMaterialDialog.update();
			this._oValueHelpMaterialDialog.open();
		},
		onValueHelpMaterialGroupF4CancelPress: function() {
			this._oValueHelpMaterialDialog.close();
		},
		onValueHelpMaterialGroupF4AfterClose: function() {
			this._oValueHelpMaterialDialog.destroy();
		},

		onSuggestionItemSelectedMaterialGroup: function(oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("idMaterialGroup").setValue(sDescription);
		},

		onValueHelpMaterialGroupF4OkPress: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idMaterialGroup");
			oInput.setTokens(aTokens);
			this._oValueHelpMaterialDialog.close();
		},
		onSearchMaterialF4: function(oEvent) {
			var aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function(aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);

			this._filterMaterialTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},

		_filterMaterialTable: function(oFilter) {
			var oTable = this._oValueHelpMaterialDialog.getTable();
			if (oTable.bindRows) {
				oTable.getBinding("rows").filter(oFilter);
			}
			if (oTable.bindItems) {
				oTable.getBinding("items").filter(oFilter);
			}
			this._oValueHelpMaterialDialog.update();
		},

		/*----------------------------------------MaterialGroup  F4 End----------------------------------------------------------------*/

		/*----------------------------------------SalesOrg  F4 Start----------------------------------------------------------------*/
		onValueHelpSalesOrg: function(oEvent) {

			this._oValueHelpSalesOrgDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE_SPARES.view.fragment.SalesOrgF4", this);
			this.getView().addDependent(this._oValueHelpSalesOrgDialog);
			var oTable = this._oValueHelpSalesOrgDialog.getTable();
			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label: this.rescrModel.getText("SalesOrganization"),
					template: "SalesOrganization"
				}, {
					label: this.rescrModel.getText("SalesOrganizationText"),
					template: "SalesOrganization_Text"
				}]
			});
			this._oValueHelpSalesOrgDialog.getTable().setModel(oColModel2, "columns");
			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/C_SalesOrganizationVH");
			}
			this._oValueHelpSalesOrgDialog.update();
			this._oValueHelpSalesOrgDialog.open();
		},
		onValueHelpSalesOrgF4OkPress: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idSalesOrg");
			oInput.setTokens(aTokens);
			this._oValueHelpSalesOrgDialog.close();
		},
		onValueHelpSalesOrgF4CancelPress: function() {
			this._oValueHelpSalesOrgDialog.close();
		},
		onValueHelpSalesOrgF4AfterClose: function() {
			this._oValueHelpSalesOrgDialog.destroy();
		},

		onSuggestionItemSelectedSalesOrg: function(oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("idSalesOrg").setValue(sDescription);
		},
		onSearchSalesOrgF4: function(oEvent) {
			var aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function(aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);

			this._filterSalesOrgTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},

		_filterSalesOrgTable: function(oFilter) {
			var oTable = this._oValueHelpSalesOrgDialog.getTable();
			if (oTable.bindRows) {
				oTable.getBinding("rows").filter(oFilter);
			}
			if (oTable.bindItems) {
				oTable.getBinding("items").filter(oFilter);
			}
			this._oValueHelpSalesOrgDialog.update();
		},
		/*----------------------------------------SalesOrg  F4 End----------------------------------------------------------------*/

		/*----------------------------------------ShipToCountry  F4 Start----------------------------------------------------------------*/

		onValueHelpShipToCountry: function(oEvent) {

			this._oValueHelpShipToCountryDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE_SPARES.view.fragment.ShipToCountryF4", this);
			this.getView().addDependent(this._oValueHelpShipToCountryDialog);
			var oTable = this._oValueHelpShipToCountryDialog.getTable();
			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label: this.rescrModel.getText("Country"),
					template: "Country"
				}, {
					label: this.rescrModel.getText("CountryText"),
					template: "Country_Text"
				}]
			});
			this._oValueHelpShipToCountryDialog.getTable().setModel(oColModel2, "columns");
			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/I_Country");
			}
			this._oValueHelpShipToCountryDialog.update();
			this._oValueHelpShipToCountryDialog.open();
		},
		onValueHelpShipToCountryF4OkPress: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idShipToCountry");
			oInput.setTokens(aTokens);
			this._oValueHelpShipToCountryDialog.close();
		},
		onValueHelpShipToCountryF4CancelPress: function() {
			this._oValueHelpShipToCountryDialog.close();
		},
		onValueHelpShipToCountryF4AfterClose: function() {
			this._oValueHelpShipToCountryDialog.destroy();
		},
		onSuggestionItemSelectedShipToCountry: function(oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("idShipToCountry").setValue(sDescription);
		},

		onSearchShipToCountryF4: function(oEvent) {
			var aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function(aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);

			this._filterShipToTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},

		_filterShipToTable: function(oFilter) {
			var oTable = this._oValueHelpShipToCountryDialog.getTable();
			if (oTable.bindRows) {
				oTable.getBinding("rows").filter(oFilter);
			}
			if (oTable.bindItems) {
				oTable.getBinding("items").filter(oFilter);
			}
			this._oValueHelpShipToCountryDialog.update();
		},
		/*----------------------------------------ShipToCountry  F4 End----------------------------------------------------------------*/

		/*----------------------------------------DistributionChannel  F4 Start----------------------------------------------------------------*/

		onValueHelpDistributionChannel: function(oEvent) {

			this._oValueHelpDistributionChannelDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE_SPARES.view.fragment.DistributionChannel", this);
			this.getView().addDependent(this._oValueHelpDistributionChannelDialog);
			var oTable = this._oValueHelpDistributionChannelDialog.getTable();
			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label: this.rescrModel.getText("DistributionChannelDesc"),
					template: "vtweg"
				}, {
					label: this.rescrModel.getText("DistributionChannelText"),
					template: "vtext"
				}]
			});
			this._oValueHelpDistributionChannelDialog.getTable().setModel(oColModel2, "columns");
			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/SHSM_H_MVKE");
			}
			this._oValueHelpDistributionChannelDialog.update();
			this._oValueHelpDistributionChannelDialog.open();
		},
		onValueHelpDistributionChannelF4OkPress: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idDistributionChannel");
			oInput.setTokens(aTokens);
			this._oValueHelpDistributionChannelDialog.close();
		},
		onValueHelpDistributionChannelF4CancelPress: function() {
			this._oValueHelpDistributionChannelDialog.close();
		},
		onValueHelpDistributionChannelF4AfterClose: function() {
			this._oValueHelpDistributionChannelDialog.destroy();
		},
		onSuggestionItemSelectedDistributionChannel: function(oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("idDistributionChannel").setValue(sDescription);
		},
		onSearchDistributionChannelF4: function(oEvent) {
			var aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function(aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);

			this._filterDistributionChannelTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},

		_filterDistributionChannelTable: function(oFilter) {
			var oTable = this._oValueHelpDistributionChannelDialog.getTable();
			if (oTable.bindRows) {
				oTable.getBinding("rows").filter(oFilter);
			}
			if (oTable.bindItems) {
				oTable.getBinding("items").filter(oFilter);
			}
			this._oValueHelpDistributionChannelDialog.update();
		},
		/*----------------------------------------DistributionChannel  F4 End----------------------------------------------------------------*/

		/*----------------------------------------IntentOfUse  F4 Start----------------------------------------------------------------*/

		onValueHelpIntentOfUse: function(oEvent) {

			this._oValueHelpIntentOfUseDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE_SPARES.view.fragment.IntentOfUse", this);
			this.getView().addDependent(this._oValueHelpIntentOfUseDialog);
			var oTable = this._oValueHelpIntentOfUseDialog.getTable();
			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label: this.rescrModel.getText("IntentOfUseDesc"),
					template: "IntentOfUse"
				}, {
					label: this.rescrModel.getText("UsageText"),
					template: "UsageText"
				}]
			});
			this._oValueHelpIntentOfUseDialog.getTable().setModel(oColModel2, "columns");
			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/IntentOfUse");
			}
			this._oValueHelpIntentOfUseDialog.update();
			this._oValueHelpIntentOfUseDialog.open();
		},
		onValueHelpIntentOfUseF4OkPress: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idIntentOfUse");
			oInput.setTokens(aTokens);
			this._oValueHelpIntentOfUseDialog.close();
		},
		onValueHelpIntentOfUseF4CancelPress: function() {
			this._oValueHelpIntentOfUseDialog.close();
		},
		onValueHelpIntentOfUseF4AfterClose: function() {
			this._oValueHelpIntentOfUseDialog.destroy();
		},
		onSuggestionItemSelectedIntentOfUse: function(oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("idIntentOfUse").setValue(sDescription);
		},
		onSearchIntentOfUseF4: function(oEvent) {
			var aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function(aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);

			this._filterIntentOfUseTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},

		_filterIntentOfUseTable: function(oFilter) {
			var oTable = this._oValueHelpIntentOfUseDialog.getTable();
			if (oTable.bindRows) {
				oTable.getBinding("rows").filter(oFilter);
			}
			if (oTable.bindItems) {
				oTable.getBinding("items").filter(oFilter);
			}
			this._oValueHelpIntentOfUseDialog.update();
		},
		/*----------------------------------------IntentOfUse  F4 End----------------------------------------------------------------*/
		onActionChange: function(evt) {
			var action = this.getView().byId("ActionSelect").getSelectedKey();
			var aFilter = [];
			if (action === "CREATE") {
				// var oList = this.getView().byId("iStatus");
				var statusVal = ["Y2", "Y4"];
			} else {
				// var oList = this.getView().byId("iStatus1");
				var statusVal = ["Y1"];
			}
			// var statusArr = [];
			// statusVal.forEach(function(item, index) {
			// 	statusArr.push(new sap.ui.model.Filter("Status", "EQ", item));
			// });
			// var statusFilter = new sap.ui.model.Filter({
			// 	filters: statusArr,
			// 	and: false
			// });
			// // filter binding

			// var oBinding = oList.getBinding("items");
			// oBinding.filter(statusFilter);
			if (action === "CREATE") {
				this.getView().byId("iStatus").setSelectedKeys(["Y2", "Y4"]);
			} else {
				this.getView().byId("iStatus").setSelectedKeys(["Y1"]);
			}
		},
		toView2Press: function() {
			var mandtFlag = this.onFilterSearch();
			if (mandtFlag) {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("PriceApproval");
			}
		}
	});
});