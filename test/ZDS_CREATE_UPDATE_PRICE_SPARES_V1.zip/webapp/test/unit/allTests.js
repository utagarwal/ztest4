sap.ui.define([
	"ZDS_CREATE_UPDATE_PRICE_SPARES/test/unit/controller/View1.controller"
], function () {
	"use strict";
});