/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"ZDS_CREATE_UPDATE_PRICE_SPARES/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"ZDS_CREATE_UPDATE_PRICE_SPARES/test/integration/pages/View1",
	"ZDS_CREATE_UPDATE_PRICE_SPARES/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "ZDS_CREATE_UPDATE_PRICE_SPARES.view.",
		autoWait: true
	});
});